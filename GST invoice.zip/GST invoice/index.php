<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GST Invoice Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    transition: background-color 0.3s, color 0.3s;
}

/* Light Mode (Default) */
body {
    background-color: #f8f9fa;
    color: #212529;
}

.border {
    border-color: #dee2e6 !important;
}

.form-control, .form-select {
    border-color: #ced4da;
}

.form-control:focus, .form-select:focus {
    border-color: #86b7fe;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

/* Dark Mode */
body.dark-mode {
    background-color: #212529;
    color: #f8f9fa;
}

body.dark-mode .container,
body.dark-mode section {
    background-color: #343a40;
    border-color: #495057 !important;
}

body.dark-mode h1,
body.dark-mode h2,
body.dark-mode .form-label {
    color: #f8f9fa;
}

body.dark-mode .form-control,
body.dark-mode .form-select {
    background-color: #495057;
    color: #f8f9fa;
    border-color: #6c757d;
}

body.dark-mode .form-control:focus,
body.dark-mode .form-select:focus {
    background-color: #495057;
    color: #f8f9fa;
    border-color: #adb5bd;
    box-shadow: 0 0 0 0.25rem rgba(108, 117, 125, 0.5);
}

body.dark-mode .form-control::placeholder {
    color: #adb5bd;
}

body.dark-mode .form-control[readonly] {
    background-color: #6c757d;
}

body.dark-mode .btn-primary {
    background-color: #0d6efd;
    border-color: #0d6efd;
}
body.dark-mode .btn-primary:hover {
    background-color: #0b5ed7;
    border-color: #0a58ca;
}

body.dark-mode .btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}
body.dark-mode .btn-danger:hover {
    background-color: #bb2d3b;
    border-color: #b02a37;
}

body.dark-mode .btn-success {
    background-color: #198754;
    border-color: #198754;
}
body.dark-mode .btn-success:hover {
    background-color: #157347;
    border-color: #146c43;
}
body.dark-mode .btn-warning {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #000;
}
body.dark-mode .btn-warning:hover {
    background-color: #ffca2c;
    border-color: #ffc720;
    color: #000;
}

body.dark-mode .table {
    color: #f8f9fa;
}

body.dark-mode .table-bordered th,
body.dark-mode .table-bordered td {
    border-color: #495057;
}

body.dark-mode #signaturePlaceholder {
    border-color: #6c757d;
    color: #adb5bd;
}


/* General Styles */
section h2 {
    margin-bottom: 1.5rem;
    font-size: 1.5rem;
    color: #0d6efd; /* Bootstrap primary color */
    padding-bottom: 0.5rem;
    border-bottom: 2px solid #0d6efd;
}

.item-row {
    transition: background-color 0.2s ease-in-out;
}

.item-row:hover {
    background-color: rgba(0, 0, 0, 0.03); /* Light hover for light mode */
}
body.dark-mode .item-row:hover {
    background-color: rgba(255, 255, 255, 0.05); /* Light hover for dark mode */
}


.btn {
    transition: transform 0.1s ease-in-out, box-shadow 0.1s ease-in-out;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.btn:active {
    transform: translateY(0px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.form-control[readonly] {
    background-color: #e9ecef;
    opacity: 1;
}

.text-danger {
    font-size: 0.875em;
}

.invalid-feedback {
    display: none; /* Hidden by default, Bootstrap handles display */
    width: 100%;
    margin-top: .25rem;
    font-size: .875em;
    color: #dc3545;
}

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

section {
    animation: fadeIn 0.5s ease-out;
}

.shadow-sm {
     box-shadow: 0 .125rem .25rem rgba(0,0,0,.075) !important;
     transition: box-shadow 0.3s ease-in-out;
}
.shadow-sm:hover {
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15) !important;
}

#signaturePlaceholder {
    border: 2px dashed #ced4da;
    min-height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-style: italic;
    transition: border-color 0.3s;
}
#signaturePlaceholder:hover {
    border-color: #0d6efd;
}
    </style>
</head>
<body>
    <div class="container mt-5 mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="mb-4">GST Invoice Generator 🧾</h1>
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" role="switch" id="darkModeToggle">
                <label class="form-check-label" for="darkModeToggle"><i class="bi bi-moon-stars-fill"></i> / <i class="bi bi-sun-fill"></i></label>
            </div>
        </div>

        <form id="gstInvoiceForm" action="generate_invoice.php" method="POST" novalidate>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Seller (Issuer) Details</h2>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="sellerBusinessName" class="form-label">Business Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sellerBusinessName" name="sellerBusinessName" required>
                        <div class="invalid-feedback">Please enter business name.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="sellerGstin" class="form-label">GSTIN <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sellerGstin" name="sellerGstin" pattern="^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$" required>
                        <div class="invalid-feedback">Please enter a valid GSTIN.</div>
                    </div>
                    <div class="col-md-12">
                        <label for="sellerAddress" class="form-label">Address <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sellerAddress" name="sellerAddress" placeholder="Street Address" required>
                        <div class="invalid-feedback">Please enter address.</div>
                    </div>
                    <div class="col-md-4">
                        <input type="text" class="form-control" id="sellerCity" name="sellerCity" placeholder="City" required>
                        <div class="invalid-feedback">Please enter city.</div>
                    </div>
                    <div class="col-md-4">
                        <input type="text" class="form-control" id="sellerState" name="sellerState" placeholder="State" required>
                        <div class="invalid-feedback">Please enter state.</div>
                    </div>
                    <div class="col-md-2">
                        <input type="text" class="form-control" id="sellerPin" name="sellerPin" placeholder="PIN Code" pattern="^[1-9][0-9]{5}$" required>
                        <div class="invalid-feedback">Please enter a valid PIN code.</div>
                    </div>
                    <div class="col-md-2">
                        <label for="sellerStateCode" class="form-label">State Code <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sellerStateCode" name="sellerStateCode" pattern="^[0-9]{2}$" required>
                        <div class="invalid-feedback">Enter 2-digit state code.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="sellerContact" class="form-label">Contact Number / Email <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sellerContact" name="sellerContact" required>
                        <div class="invalid-feedback">Please enter contact number or email.</div>
                    </div>
                </div>
            </section>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Buyer (Recipient) Details</h2>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="buyerName" class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="buyerName" name="buyerName" required>
                        <div class="invalid-feedback">Please enter buyer's name.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="buyerGstin" class="form-label">GSTIN (Optional)</label>
                        <input type="text" class="form-control" id="buyerGstin" name="buyerGstin" pattern="^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$">
                        <div class="invalid-feedback">Please enter a valid GSTIN or leave blank.</div>
                    </div>
                    <div class="col-md-12">
                        <label for="buyerAddress" class="form-label">Address <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="buyerAddress" name="buyerAddress" placeholder="Street Address" required>
                         <div class="invalid-feedback">Please enter address.</div>
                    </div>
                     <div class="col-md-6">
                        <label for="buyerState" class="form-label">State <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="buyerState" name="buyerState" required>
                        <div class="invalid-feedback">Please enter state.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="buyerStateCode" class="form-label">State Code <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="buyerStateCode" name="buyerStateCode" pattern="^[0-9]{2}$" required>
                        <div class="invalid-feedback">Enter 2-digit state code.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="buyerContact" class="form-label">Contact Number / Email</label>
                        <input type="text" class="form-control" id="buyerContact" name="buyerContact">
                    </div>
                </div>
            </section>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Invoice Details</h2>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="invoiceNumber" class="form-label">Invoice Number <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="invoiceNumber" name="invoiceNumber" required>
                        <div class="invalid-feedback">Please enter invoice number.</div>
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" role="switch" id="autoInvoiceNumber">
                            <label class="form-check-label" for="autoInvoiceNumber">Auto-generate</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="invoiceDate" class="form-label">Invoice Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="invoiceDate" name="invoiceDate" required>
                        <div class="invalid-feedback">Please select invoice date.</div>
                    </div>
                    <div class="col-md-4">
                        <label for="dueDate" class="form-label">Due Date</label>
                        <input type="date" class="form-control" id="dueDate" name="dueDate">
                    </div>
                    <div class="col-md-12">
                        <label for="paymentTerms" class="form-label">Payment Terms</label>
                        <textarea class="form-control" id="paymentTerms" name="paymentTerms" rows="2"></textarea>
                    </div>
                </div>
            </section>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Product/Service Details</h2>
                <div id="itemsContainer">
                    <div class="row g-3 item-row mb-3 align-items-end p-2 border rounded">
                        <div class="col-md-2">
                            <label class="form-label">Item/Service <span class="text-danger">*</span></label>
                            <input type="text" class="form-control itemName" name="items[0][name]" required>
                            <div class="invalid-feedback">Required.</div>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">HSN/SAC <span class="text-danger">*</span></label>
                            <input type="text" class="form-control hsnSac" name="items[0][hsn]" required>
                            <div class="invalid-feedback">Required.</div>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Qty <span class="text-danger">*</span></label>
                            <input type="number" class="form-control quantity" name="items[0][qty]" min="0" step="any" required>
                             <div class="invalid-feedback"> > 0</div>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Unit <span class="text-danger">*</span></label>
                            <input type="text" class="form-control unit" name="items[0][unit]" required>
                            <div class="invalid-feedback">e.g., pcs, kgs</div>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Rate <span class="text-danger">*</span></label>
                            <input type="number" class="form-control rate" name="items[0][rate]" min="0" step="any" required>
                            <div class="invalid-feedback"> > 0</div>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Discount</label>
                            <input type="number" class="form-control discount" name="items[0][discount]" min="0" step="any" value="0">
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">GST Rate (%) <span class="text-danger">*</span></label>
                            <select class="form-select gstRate" name="items[0][gstRate]" required>
                                <option value="">Select</option>
                                <option value="0">0</option>
                                <option value="0.1">0.1</option>
                                <option value="0.25">0.25</option>
                                <option value="3">3</option>
                                <option value="5">5</option>
                                <option value="12">12</option>
                                <option value="18">18</option>
                                <option value="28">28</option>
                            </select>
                            <div class="invalid-feedback">Select GST Rate.</div>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Total Item Amt</label>
                            <input type="text" class="form-control totalItemAmount" name="items[0][total]" readonly>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-danger removeItemBtn"><i class="bi bi-trash"></i></button>
                        </div>
                        <input type="hidden" class="taxableValueItem" name="items[0][taxableValue]">
                        <input type="hidden" class="cgstAmountItem" name="items[0][cgst]">
                        <input type="hidden" class="sgstAmountItem" name="items[0][sgst]">
                        <input type="hidden" class="igstAmountItem" name="items[0][igst]">
                    </div>
                </div>
                <button type="button" id="addItemBtn" class="btn btn-primary mt-2"><i class="bi bi-plus-circle"></i> Add Item</button>
            </section>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Invoice Summary</h2>
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Total Taxable Value</label>
                        <input type="text" class="form-control" id="totalTaxableValue" name="totalTaxableValue" readonly>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Total CGST</label>
                        <input type="text" class="form-control" id="totalCgst" name="totalCgst" readonly>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Total SGST/UTGST</label>
                        <input type="text" class="form-control" id="totalSgst" name="totalSgst" readonly>
                    </div>
                     <div class="col-md-3">
                        <label class="form-label">Total IGST</label>
                        <input type="text" class="form-control" id="totalIgst" name="totalIgst" readonly>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Grand Total (Invoice Value)</label>
                        <input type="text" class="form-control fw-bold" id="grandTotal" name="grandTotal" readonly>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Amount in Words</label>
                        <input type="text" class="form-control" id="amountInWords" name="amountInWords" readonly>
                    </div>
                </div>
            </section>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Additional Details (Optional)</h2>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="placeOfSupply" class="form-label">Place of Supply (State - State Code)</label>
                        <input type="text" class="form-control" id="placeOfSupply" name="placeOfSupply" placeholder="e.g., Delhi - 07">
                    </div>
                    <div class="col-md-4">
                        <label for="transportationMode" class="form-label">Transportation Mode / Vehicle No.</label>
                        <input type="text" class="form-control" id="transportationMode" name="transportationMode">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Reverse Charge Applicable?</label>
                        <select class="form-select" id="reverseCharge" name="reverseCharge">
                            <option value="No" selected>No</option>
                            <option value="Yes">Yes</option>
                        </select>
                    </div>
                </div>
            </section>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Bank Details</h2>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="bankName" class="form-label">Bank Name</label>
                        <input type="text" class="form-control" id="bankName" name="bankName">
                    </div>
                    <div class="col-md-4">
                        <label for="accountNumber" class="form-label">Account Number</label>
                        <input type="text" class="form-control" id="accountNumber" name="accountNumber">
                    </div>
                    <div class="col-md-4">
                        <label for="ifscCode" class="form-label">IFSC Code</label>
                        <input type="text" class="form-control" id="ifscCode" name="ifscCode">
                    </div>
                </div>
            </section>

            <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Notes & Declaration</h2>
                <div class="mb-3">
                    <label for="notes" class="form-label">Notes / Terms & Conditions</label>
                    <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                </div>
                <div class="mb-3">
                    <label for="declaration" class="form-label">Declaration</label>
                    <textarea class="form-control" id="declaration" name="declaration" rows="2" readonly>We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</textarea>
                </div>
            </section>

             <section class="mb-4 p-3 border rounded shadow-sm">
                <h2>Authorized Signatory</h2>
                 <div class="row g-3">
                    <div class="col-md-6">
                        <label for="authorizedSignatory" class="form-label">Name</label>
                        <input type="text" class="form-control" id="authorizedSignatory" name="authorizedSignatory">
                    </div>
                    <div class="col-md-6">
                        <label for="signaturePlaceholder" class="form-label">Digital Signature Placeholder</label>
                        <div id="signaturePlaceholder" class="form-control" style="height: 100px; border-style: dashed; text-align: center; line-height: 100px;">
                            (Signature will appear here in generated invoice)
                        </div>
                    </div>
                </div>
            </section>

            <div class="text-center mt-4">
                <button type="submit" class="btn btn-success btn-lg"><i class="bi bi-file-earmark-check"></i> Generate Invoice</button>
                <button type="reset" class="btn btn-warning btn-lg"><i class="bi bi-arrow-counterclockwise"></i> Reset Form</button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
    // Dark Mode Toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (localStorage.getItem('darkMode') === 'enabled') {
        document.body.classList.add('dark-mode');
        darkModeToggle.checked = true;
    }
    darkModeToggle.addEventListener('change', () => {
        if (darkModeToggle.checked) {
            document.body.classList.add('dark-mode');
            localStorage.setItem('darkMode', 'enabled');
        } else {
            document.body.classList.remove('dark-mode');
            localStorage.setItem('darkMode', 'disabled');
        }
    });

    // Set default invoice date
    const invoiceDateInput = document.getElementById('invoiceDate');
    if (!invoiceDateInput.value) {
        invoiceDateInput.valueAsDate = new Date();
    }

    // Auto Invoice Number (Conceptual - needs backend for true uniqueness)
    const autoInvoiceNumberCheckbox = document.getElementById('autoInvoiceNumber');
    const invoiceNumberInput = document.getElementById('invoiceNumber');
    autoInvoiceNumberCheckbox.addEventListener('change', () => {
        if (autoInvoiceNumberCheckbox.checked) {
            invoiceNumberInput.value = `INV-${Date.now().toString().slice(-6)}`; // Simple example
            invoiceNumberInput.readOnly = true;
        } else {
            invoiceNumberInput.readOnly = false;
        }
    });

    // Add/Remove Item Rows
    const itemsContainer = document.getElementById('itemsContainer');
    const addItemBtn = document.getElementById('addItemBtn');
    let itemIndex = 1; // Start index for next item

    // Clone the first item row to use as a template
    const itemRowTemplate = itemsContainer.querySelector('.item-row').cloneNode(true);
    // Clear values from the template
    itemRowTemplate.querySelectorAll('input, select').forEach(input => {
        if (input.type !== 'button' && input.type !== 'select-one') {
            input.value = '';
        } else if (input.type === 'select-one') {
            input.selectedIndex = 0;
        }
        if (input.classList.contains('discount')) input.value = '0';
    });
    itemRowTemplate.querySelector('.totalItemAmount').value = ''; // Clear readonly total


    addItemBtn.addEventListener('click', () => {
        const newItemRow = itemRowTemplate.cloneNode(true);
        newItemRow.querySelectorAll('[name]').forEach(el => {
            const nameAttr = el.getAttribute('name');
            if (nameAttr) {
                el.setAttribute('name', nameAttr.replace(/\[\d+\]/, `[${itemIndex}]`));
            }
        });
        newItemRow.querySelectorAll('input, select').forEach(input => input.classList.remove('is-invalid')); // Clear validation state
        itemsContainer.appendChild(newItemRow);
        attachRemoveListeners();
        attachCalculationListenersToRow(newItemRow);
        itemIndex++;
    });

    function attachRemoveListeners() {
        itemsContainer.querySelectorAll('.removeItemBtn').forEach(btn => {
            btn.removeEventListener('click', handleRemoveItem); // Prevent multiple listeners
            btn.addEventListener('click', handleRemoveItem);
        });
    }

    function handleRemoveItem(event) {
        if (itemsContainer.querySelectorAll('.item-row').length > 1) {
            event.target.closest('.item-row').remove();
            calculateAllTotals();
        } else {
            alert("At least one item is required.");
        }
    }

    // Initial listeners for the first row
    attachCalculationListenersToRow(itemsContainer.querySelector('.item-row'));
    attachRemoveListeners();


    // Calculations
    function attachCalculationListenersToRow(row) {
        const inputsToWatch = row.querySelectorAll('.quantity, .rate, .discount, .gstRate');
        inputsToWatch.forEach(input => {
            input.addEventListener('input', () => {
                calculateItemTotal(row);
                calculateAllTotals();
            });
        });
    }

    function calculateItemTotal(row) {
        const quantity = parseFloat(row.querySelector('.quantity').value) || 0;
        const rate = parseFloat(row.querySelector('.rate').value) || 0;
        const discount = parseFloat(row.querySelector('.discount').value) || 0; // Discount is a value, not percentage here
        const gstRate = parseFloat(row.querySelector('.gstRate').value) || 0;

        const sellerStateCode = document.getElementById('sellerStateCode').value.trim();
        const buyerStateCode = document.getElementById('buyerStateCode').value.trim();

        let taxableValue = (quantity * rate) - discount;
        if (taxableValue < 0) taxableValue = 0;

        let cgstAmount = 0;
        let sgstAmount = 0;
        let igstAmount = 0;
        let gstAmount = 0;

        if (gstRate > 0 && taxableValue > 0) {
            if (sellerStateCode && buyerStateCode && sellerStateCode === buyerStateCode) {
                cgstAmount = (taxableValue * (gstRate / 2)) / 100;
                sgstAmount = (taxableValue * (gstRate / 2)) / 100;
                gstAmount = cgstAmount + sgstAmount;
            } else if (sellerStateCode && buyerStateCode && sellerStateCode !== buyerStateCode) {
                igstAmount = (taxableValue * gstRate) / 100;
                gstAmount = igstAmount;
            } else {
                // Fallback or handle case where state codes are missing - for now, assume IGST if unsure
                // Or you might want to prevent calculation and show an error.
                // For simplicity here, if one is missing, we'll calculate IGST.
                // In a real app, you'd enforce state code entry for accurate GST.
                 igstAmount = (taxableValue * gstRate) / 100;
                 gstAmount = igstAmount;
                 if(!sellerStateCode || !buyerStateCode) {
                    console.warn("Seller or Buyer state code is missing. GST calculation might be inaccurate (defaulting to IGST).");
                 }
            }
        }

        const totalItemAmount = taxableValue + gstAmount;

        row.querySelector('.taxableValueItem').value = taxableValue.toFixed(2);
        row.querySelector('.cgstAmountItem').value = cgstAmount.toFixed(2);
        row.querySelector('.sgstAmountItem').value = sgstAmount.toFixed(2);
        row.querySelector('.igstAmountItem').value = igstAmount.toFixed(2);
        row.querySelector('.totalItemAmount').value = totalItemAmount.toFixed(2);
    }

    function calculateAllTotals() {
        let totalTaxable = 0;
        let totalCgst = 0;
        let totalSgst = 0;
        let totalIgst = 0;
        let grandTotal = 0;

        itemsContainer.querySelectorAll('.item-row').forEach(row => {
            totalTaxable += parseFloat(row.querySelector('.taxableValueItem').value) || 0;
            totalCgst += parseFloat(row.querySelector('.cgstAmountItem').value) || 0;
            totalSgst += parseFloat(row.querySelector('.sgstAmountItem').value) || 0;
            totalIgst += parseFloat(row.querySelector('.igstAmountItem').value) || 0;
            grandTotal += parseFloat(row.querySelector('.totalItemAmount').value) || 0;
        });

        document.getElementById('totalTaxableValue').value = totalTaxable.toFixed(2);
        document.getElementById('totalCgst').value = totalCgst.toFixed(2);
        document.getElementById('totalSgst').value = totalSgst.toFixed(2);
        document.getElementById('totalIgst').value = totalIgst.toFixed(2);
        document.getElementById('grandTotal').value = grandTotal.toFixed(2);
        document.getElementById('amountInWords').value = numberToWords(grandTotal);
    }

    // Re-calculate if state codes change
    document.getElementById('sellerStateCode').addEventListener('input', calculateAllItemTaxesAndUpdateTotals);
    document.getElementById('buyerStateCode').addEventListener('input', calculateAllItemTaxesAndUpdateTotals);

    function calculateAllItemTaxesAndUpdateTotals() {
        itemsContainer.querySelectorAll('.item-row').forEach(row => {
            calculateItemTotal(row); // This will re-evaluate CGST/SGST/IGST
        });
        calculateAllTotals();
    }


    // Form Validation (Bootstrap 5)
    const form = document.getElementById('gstInvoiceForm');
    form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }
        form.classList.add('was-validated');

        // Custom validation for at least one item
        if (itemsContainer.querySelectorAll('.item-row').length === 0) {
            alert("Please add at least one item/service.");
            event.preventDefault();
            event.stopPropagation();
        }
    }, false);


    // Number to Words (Simplified - for full version, use a library or more robust function)
    function numberToWords(num) {
        if (num === 0) return "Zero";
        const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
        const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
        const s = num.toString();
        if (s.length > 9) return 'Too Large (Overflow)'; // Handle larger numbers as needed

        const n = ('000000000' + s).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) return;
        let str = '';
        str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + ' Crore ' : '';
        str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + ' Lakh ' : '';
        str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + ' Thousand ' : '';
        str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + ' Hundred ' : '';
        str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) : '';

        // Handling decimal part
        const decimalPart = s.split('.')[1];
        if (decimalPart && parseInt(decimalPart) > 0) {
            str += ' and ' + decimalPart + '/100';
        }
        return str.replace(/\s+/g, ' ').trim() + " Only";
    }

    // Initial calculation for any pre-filled item data (though in this setup, it starts empty)
    calculateAllTotals();
});
    </script>
</body>
</html>