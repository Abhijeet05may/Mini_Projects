<?php
// generate_invoice.php

// Basic error reporting - turn off for production
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize all POST data
    $_POST = sanitize_input($_POST);

    // Seller Details
    $sellerBusinessName = $_POST['sellerBusinessName'] ?? 'N/A';
    $sellerGstin = $_POST['sellerGstin'] ?? 'N/A';
    $sellerAddress = $_POST['sellerAddress'] ?? 'N/A';
    $sellerCity = $_POST['sellerCity'] ?? 'N/A';
    $sellerState = $_POST['sellerState'] ?? 'N/A';
    $sellerPin = $_POST['sellerPin'] ?? 'N/A';
    $sellerStateCode = $_POST['sellerStateCode'] ?? 'N/A';
    $sellerContact = $_POST['sellerContact'] ?? 'N/A';

    // Buyer Details
    $buyerName = $_POST['buyerName'] ?? 'N/A';
    $buyerGstin = $_POST['buyerGstin'] ?: 'N/A (Unregistered)';
    $buyerAddress = $_POST['buyerAddress'] ?? 'N/A';
    $buyerState = $_POST['buyerState'] ?? 'N/A';
    $buyerStateCode = $_POST['buyerStateCode'] ?? 'N/A';
    $buyerContact = $_POST['buyerContact'] ?? 'N/A';

    // Invoice Details
    $invoiceNumber = $_POST['invoiceNumber'] ?? 'N/A';
    $invoiceDate = $_POST['invoiceDate'] ?? 'N/A';
    $dueDate = $_POST['dueDate'] ?: 'N/A';
    $paymentTerms = nl2br($_POST['paymentTerms'] ?? 'N/A'); // Preserve line breaks

    // Items
    $items = $_POST['items'] ?? [];

    // Invoice Summary
    $totalTaxableValue = $_POST['totalTaxableValue'] ?? '0.00';
    $totalCgst = $_POST['totalCgst'] ?? '0.00';
    $totalSgst = $_POST['totalSgst'] ?? '0.00';
    $totalIgst = $_POST['totalIgst'] ?? '0.00';
    $grandTotal = $_POST['grandTotal'] ?? '0.00';
    $amountInWords = $_POST['amountInWords'] ?? 'N/A';

    // Additional Fields
    $placeOfSupply = $_POST['placeOfSupply'] ?: 'N/A';
    $transportationMode = $_POST['transportationMode'] ?: 'N/A';
    $reverseCharge = $_POST['reverseCharge'] ?? 'No';

    // Bank Details
    $bankName = $_POST['bankName'] ?: 'N/A';
    $accountNumber = $_POST['accountNumber'] ?: 'N/A';
    $ifscCode = $_POST['ifscCode'] ?: 'N/A';

    // Notes & Signatory
    $notes = nl2br($_POST['notes'] ?? 'N/A');
    $declaration = nl2br($_POST['declaration'] ?? 'We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.');
    $authorizedSignatory = $_POST['authorizedSignatory'] ?: 'N/A';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GST Invoice - <?php echo $invoiceNumber; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; color: #333; }
        .invoice-container { max-width: 800px; margin: 20px auto; background: #fff; padding: 20px; border: 1px solid #ddd; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .invoice-header, .invoice-footer { text-align: center; margin-bottom: 20px; }
        .invoice-header h1 { margin: 0; color: #333; }
        .section-title { background-color: #f2f2f2; padding: 8px; margin-top: 20px; margin-bottom: 10px; font-weight: bold; border-top: 1px solid #ddd; border-bottom: 1px solid #ddd;}
        .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .details-grid div { padding: 5px; }
        .details-grid strong { display: block; margin-bottom: 3px; color: #555; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f9f9f9; }
        .text-end { text-align: right; }
        .fw-bold { font-weight: bold; }
        .notes-section { margin-top: 20px; padding: 10px; border: 1px dashed #ccc; font-size: 0.9em; }
        .signature-area { margin-top: 50px; padding-top: 20px; border-top: 1px solid #eee; }
        .signature-box { border: 1px dashed #ccc; height: 80px; width: 200px; margin-top: 5px; text-align: center; line-height:80px; color:#aaa; }
        @media print {
            body { background-color: #fff; -webkit-print-color-adjust: exact; /* Chrome, Safari, Edge */ color-adjust: exact; /* Firefox */ }
            .invoice-container { margin: 0; border: none; box-shadow: none; width: 100%; max-width: 100%;}
            .btn-print { display: none; }
            .section-title { background-color: #f2f2f2 !important; } /* Ensure background prints */
            th { background-color: #f9f9f9 !important; } /* Ensure background prints */
        }
        .btn-print {
            display: block; width: 100px; margin: 20px auto; padding: 10px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; text-align:center;
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <button class="btn-print" onclick="window.print()">Print</button>

        <div class="invoice-header">
            <h1>Tax Invoice</h1>
        </div>

        <div class="details-grid">
            <div>
                <div class="section-title">Seller (Issuer) Details</div>
                <strong><?php echo $sellerBusinessName; ?></strong>
                GSTIN: <?php echo $sellerGstin; ?><br>
                <?php echo $sellerAddress; ?><br>
                <?php echo $sellerCity . ", " . $sellerState . " - " . $sellerPin; ?><br>
                State Code: <?php echo $sellerStateCode; ?><br>
                Contact: <?php echo $sellerContact; ?>
            </div>
            <div>
                <div class="section-title">Buyer (Recipient) Details</div>
                <strong><?php echo $buyerName; ?></strong>
                GSTIN: <?php echo $buyerGstin; ?><br>
                <?php echo $buyerAddress; ?><br>
                State: <?php echo $buyerState; ?><br>
                State Code: <?php echo $buyerStateCode; ?><br>
                Contact: <?php echo $buyerContact; ?>
            </div>
        </div>

        <div class="details-grid">
            <div>
                <strong>Invoice No.:</strong> <?php echo $invoiceNumber; ?><br>
                <strong>Invoice Date:</strong> <?php echo date("d-M-Y", strtotime($invoiceDate)); ?><br>
                <strong>Due Date:</strong> <?php echo $dueDate != 'N/A' ? date("d-M-Y", strtotime($dueDate)) : 'N/A'; ?>
            </div>
            <div>
                <strong>Place of Supply:</strong> <?php echo $placeOfSupply; ?><br>
                <?php if($transportationMode !== 'N/A'): ?>
                    <strong>Transportation:</strong> <?php echo $transportationMode; ?><br>
                <?php endif; ?>
                <strong>Reverse Charge:</strong> <?php echo $reverseCharge; ?>
            </div>
        </div>

        <div class="section-title">Product/Service Details</div>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Item/Service</th>
                    <th>HSN/SAC</th>
                    <th>Qty</th>
                    <th>Unit</th>
                    <th>Rate</th>
                    <th>Discount</th>
                    <th>Taxable Value</th>
                    <?php if ($totalCgst > 0 || $totalSgst > 0): ?>
                    <th>CGST (%)</th>
                    <th>CGST Amt</th>
                    <th>SGST/UTGST (%)</th>
                    <th>SGST/UTGST Amt</th>
                    <?php elseif ($totalIgst > 0): ?>
                    <th>IGST (%)</th>
                    <th>IGST Amt</th>
                    <?php else: // For 0% GST items ?>
                    <th>GST (%)</th>
                    <th>GST Amt</th>
                    <?php endif; ?>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $itemNo = 1;
                foreach ($items as $item):
                    $itemName = $item['name'] ?? 'N/A';
                    $hsn = $item['hsn'] ?? 'N/A';
                    $qty = floatval($item['qty'] ?? 0);
                    $unit = $item['unit'] ?? 'N/A';
                    $rate = floatval($item['rate'] ?? 0);
                    $discount = floatval($item['discount'] ?? 0);
                    $gstRateVal = floatval($item['gstRate'] ?? 0);

                    $itemTaxableValue = floatval($item['taxableValue'] ?? 0);
                    $itemCgst = floatval($item['cgst'] ?? 0);
                    $itemSgst = floatval($item['sgst'] ?? 0);
                    $itemIgst = floatval($item['igst'] ?? 0);
                    $itemTotal = floatval($item['total'] ?? 0);
                ?>
                <tr>
                    <td><?php echo $itemNo++; ?></td>
                    <td><?php echo $itemName; ?></td>
                    <td><?php echo $hsn; ?></td>
                    <td class="text-end"><?php echo number_format($qty, 2); ?></td>
                    <td><?php echo $unit; ?></td>
                    <td class="text-end"><?php echo number_format($rate, 2); ?></td>
                    <td class="text-end"><?php echo number_format($discount, 2); ?></td>
                    <td class="text-end"><?php echo number_format($itemTaxableValue, 2); ?></td>

                    <?php if ($totalCgst > 0 || $totalSgst > 0): ?>
                        <td class="text-end"><?php echo $gstRateVal > 0 ? number_format($gstRateVal / 2, 2) : '0.00'; ?></td>
                        <td class="text-end"><?php echo number_format($itemCgst, 2); ?></td>
                        <td class="text-end"><?php echo $gstRateVal > 0 ? number_format($gstRateVal / 2, 2) : '0.00'; ?></td>
                        <td class="text-end"><?php echo number_format($itemSgst, 2); ?></td>
                    <?php elseif ($totalIgst > 0): ?>
                        <td class="text-end"><?php echo number_format($gstRateVal, 2); ?></td>
                        <td class="text-end"><?php echo number_format($itemIgst, 2); ?></td>
                    <?php else: // For 0% GST items ?>
                        <td class="text-end">0.00</td>
                        <td class="text-end">0.00</td>
                    <?php endif; ?>
                    <td class="text-end fw-bold"><?php echo number_format($itemTotal, 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="<?php echo ($totalCgst > 0 || $totalSgst > 0 || $totalIgst > 0) ? '7' : '7'; ?>" class="text-end fw-bold">Total Taxable Value:</td>
                    <td class="text-end fw-bold"><?php echo number_format((float)$totalTaxableValue, 2); ?></td>
                    <?php if ($totalCgst > 0 || $totalSgst > 0): ?>
                        <td colspan="2"></td>
                        <td colspan="2"></td>
                    <?php elseif ($totalIgst > 0): ?>
                         <td colspan="1"></td>
                    <?php else: ?>
                        <td colspan="1"></td>
                    <?php endif; ?>
                    <td></td>
                </tr>
                <?php if ($totalCgst > 0): ?>
                <tr>
                    <td colspan="<?php echo ($totalCgst > 0 || $totalSgst > 0 || $totalIgst > 0) ? '7' : '7'; ?>" class="text-end">Add: Total CGST:</td>
                    <td></td>
                    <td class="text-end"><?php echo number_format((float)$totalCgst, 2); ?></td>
                    <td colspan="2"></td><td></td>
                </tr>
                <?php endif; ?>
                <?php if ($totalSgst > 0): ?>
                <tr>
                    <td colspan="<?php echo ($totalCgst > 0 || $totalSgst > 0 || $totalIgst > 0) ? '7' : '7'; ?>" class="text-end">Add: Total SGST/UTGST:</td>
                    <td></td><td></td><td></td>
                    <td class="text-end"><?php echo number_format((float)$totalSgst, 2); ?></td>
                    <td></td>
                </tr>
                <?php endif; ?>
                <?php if ($totalIgst > 0): ?>
                <tr>
                    <td colspan="<?php echo ($totalCgst > 0 || $totalSgst > 0 || $totalIgst > 0) ? '7' : '7'; ?>" class="text-end">Add: Total IGST:</td>
                    <td></td>
                    <td class="text-end"><?php echo number_format((float)$totalIgst, 2); ?></td>
                    <td></td>
                </tr>
                <?php endif; ?>
                 <tr>
                    <td colspan="<?php echo ($totalCgst > 0 || $totalSgst > 0 || $totalIgst > 0) ? '7' : '7'; ?>" class="text-end fw-bold">Total Tax Amount (GST):</td>
                    <td class="text-end fw-bold"><?php echo number_format((float)$totalCgst + (float)$totalSgst + (float)$totalIgst, 2); ?></td>
                    <?php if ($totalCgst > 0 || $totalSgst > 0): ?>
                        <td colspan="2"></td>
                        <td colspan="2"></td>
                    <?php elseif ($totalIgst > 0): ?>
                         <td colspan="1"></td>
                    <?php else: ?>
                        <td colspan="1"></td>
                    <?php endif; ?>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="<?php echo ($totalCgst > 0 || $totalSgst > 0 || $totalIgst > 0) ? '7' : '7'; ?>" class="text-end fw-bold" style="font-size:1.1em; background-color: #f0f0f0;">GRAND TOTAL:</td>
                    <td class="text-end fw-bold" style="font-size:1.1em; background-color: #f0f0f0;"></td>
                     <?php if ($totalCgst > 0 || $totalSgst > 0): ?>
                        <td colspan="2"></td>
                        <td colspan="2"></td>
                    <?php elseif ($totalIgst > 0): ?>
                         <td colspan="1"></td>
                    <?php else: ?>
                        <td colspan="1"></td>
                    <?php endif; ?>
                    <td class="text-end fw-bold" style="font-size:1.1em; background-color: #f0f0f0;"><?php echo number_format((float)$grandTotal, 2); ?></td>
                </tr>
            </tfoot>
        </table>

        <div>
            <strong>Amount in Words:</strong> <?php echo $amountInWords; ?>
        </div>

        <?php if ($paymentTerms !== 'N/A' && !empty(trim(strip_tags($paymentTerms)))): ?>
        <div class="notes-section">
            <strong>Payment Terms:</strong><br>
            <?php echo $paymentTerms; ?>
        </div>
        <?php endif; ?>

        <?php if (($bankName !== 'N/A' && !empty($bankName)) || ($accountNumber !== 'N/A' && !empty($accountNumber)) || ($ifscCode !== 'N/A' && !empty($ifscCode)) ): ?>
        <div class="section-title" style="margin-top:15px;">Bank Details for Payment</div>
        <p>
            <?php if ($bankName !== 'N/A' && !empty($bankName)): ?><strong>Bank Name:</strong> <?php echo $bankName; ?><br><?php endif; ?>
            <?php if ($accountNumber !== 'N/A' && !empty($accountNumber)): ?><strong>Account Number:</strong> <?php echo $accountNumber; ?><br><?php endif; ?>
            <?php if ($ifscCode !== 'N/A' && !empty($ifscCode)): ?><strong>IFSC Code:</strong> <?php echo $ifscCode; ?><?php endif; ?>
        </p>
        <?php endif; ?>


        <?php if ($notes !== 'N/A' && !empty(trim(strip_tags($notes)))): ?>
        <div class="notes-section">
            <strong>Notes:</strong><br>
            <?php echo $notes; ?>
        </div>
        <?php endif; ?>

        <div class="notes-section" style="margin-top:10px; border-style:none; padding-left:0;">
            <strong>Declaration:</strong><br>
            <?php echo $declaration; ?>
        </div>

        <div class="signature-area details-grid">
            <div>
                </div>
            <div class="text-end">
                For <strong><?php echo $sellerBusinessName; ?></strong><br><br>
                <div class="signature-box" style="margin-left:auto;">(Digital Signature Placeholder)</div>
                <strong><?php echo $authorizedSignatory; ?></strong><br>
                Authorized Signatory
            </div>
        </div>

        <div class="invoice-footer">
            <p>This is a computer-generated invoice.</p>
        </div>
         <button class="btn-print" onclick="window.print()">Print</button>
    </div>
</body>
</html>
<?php
    exit; // Stop further script execution
} else {
    // If not a POST request, redirect to form or show an error
    // header("Location: index.html");
    echo "Invalid request method.";
    exit;
}
?>