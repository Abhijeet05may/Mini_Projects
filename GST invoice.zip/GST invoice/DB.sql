-- SQL Schema for GST Invoice Generator

-- --------------------------------------------------------
--
-- Table structure for table `sellers`
-- (Stores details of the business issuing the invoice)
--
CREATE TABLE IF NOT EXISTS `sellers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `business_name` VARCHAR(255) NOT NULL,
  `gstin` VARCHAR(15) NOT NULL UNIQUE,
  `address` TEXT NOT NULL,
  `city` VARCHAR(100) NOT NULL,
  `state` VARCHAR(100) NOT NULL,
  `pin_code` VARCHAR(10) NOT NULL,
  `state_code` VARCHAR(2) NOT NULL COMMENT 'GST State Code',
  `contact_info` VARCHAR(255) NOT NULL COMMENT 'Phone number or Email',
  `bank_name` VARCHAR(255) DEFAULT NULL,
  `account_number` VARCHAR(50) DEFAULT NULL,
  `ifsc_code` VARCHAR(20) DEFAULT NULL,
  `authorized_signatory` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add index for faster GISTIN lookup
ALTER TABLE `sellers` ADD INDEX `idx_seller_gstin` (`gstin`);

-- --------------------------------------------------------
--
-- Table structure for table `buyers`
-- (Stores details of the recipient of the invoice)
--
CREATE TABLE IF NOT EXISTS `buyers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `gstin` VARCHAR(15) DEFAULT NULL COMMENT 'Optional, can be NULL for B2C',
  `address` TEXT NOT NULL,
  `city` VARCHAR(100) NOT NULL, -- Added city for buyer
  `state` VARCHAR(100) NOT NULL,
  `pin_code` VARCHAR(10) NOT NULL, -- Added pin_code for buyer
  `state_code` VARCHAR(2) NOT NULL COMMENT 'GST State Code',
  `contact_info` VARCHAR(255) DEFAULT NULL COMMENT 'Phone number or Email',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add index for faster GISTIN lookup (if used frequently)
-- and for name as buyers might be looked up by name too.
ALTER TABLE `buyers` ADD INDEX `idx_buyer_gstin` (`gstin`);
ALTER TABLE `buyers` ADD INDEX `idx_buyer_name` (`name`);

-- --------------------------------------------------------
--
-- Table structure for table `invoices`
-- (Stores the main details of each invoice)
--
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_number` VARCHAR(50) NOT NULL UNIQUE,
  `invoice_date` DATE NOT NULL,
  `due_date` DATE DEFAULT NULL,
  `payment_terms` TEXT DEFAULT NULL,
  `seller_id` INT NOT NULL,
  `buyer_id` INT NOT NULL,
  `total_taxable_value` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `total_cgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `total_sgst_utgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `total_igst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `amount_in_words` VARCHAR(500) DEFAULT NULL,
  `place_of_supply` VARCHAR(100) DEFAULT NULL COMMENT 'e.g., State - State Code',
  `transportation_mode` VARCHAR(100) DEFAULT NULL,
  `vehicle_number` VARCHAR(50) DEFAULT NULL,
  `reverse_charge` ENUM('Yes', 'No') DEFAULT 'No',
  `notes` TEXT DEFAULT NULL,
  `declaration` TEXT DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'Generated' COMMENT 'e.g., Generated, Sent, Paid, Cancelled',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`seller_id`) REFERENCES `sellers`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (`buyer_id`) REFERENCES `buyers`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add indexes for faster lookups
ALTER TABLE `invoices` ADD INDEX `idx_invoice_date` (`invoice_date`);
ALTER TABLE `invoices` ADD INDEX `idx_invoice_seller_id` (`seller_id`);
ALTER TABLE `invoices` ADD INDEX `idx_invoice_buyer_id` (`buyer_id`);

-- --------------------------------------------------------
--
-- Table structure for table `invoice_items`
-- (Stores individual product/service line items for each invoice)
--
CREATE TABLE IF NOT EXISTS `invoice_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_id` INT NOT NULL,
  `item_name` VARCHAR(255) NOT NULL,
  `hsn_sac_code` VARCHAR(20) NOT NULL,
  `quantity` DECIMAL(10,2) NOT NULL,
  `unit` VARCHAR(20) NOT NULL,
  `rate_per_unit` DECIMAL(15,2) NOT NULL,
  `discount_amount` DECIMAL(15,2) DEFAULT 0.00, -- Storing discount as an amount
  `taxable_value` DECIMAL(15,2) NOT NULL,
  `gst_rate_percentage` DECIMAL(5,2) NOT NULL COMMENT 'e.g., 18.00 for 18%',
  `cgst_amount` DECIMAL(15,2) DEFAULT 0.00,
  `sgst_utgst_amount` DECIMAL(15,2) DEFAULT 0.00,
  `igst_amount` DECIMAL(15,2) DEFAULT 0.00,
  `total_item_amount` DECIMAL(15,2) NOT NULL COMMENT 'Taxable Value + GST Amount for the item',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`invoice_id`) REFERENCES `invoices`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add index for faster lookups
ALTER TABLE `invoice_items` ADD INDEX `idx_item_invoice_id` (`invoice_id`);

-- --------------------------------------------------------

-- Optional: If you want to store predefined GST rates or HSN codes
-- CREATE TABLE IF NOT EXISTS `gst_rates` (
--   `id` INT AUTO_INCREMENT PRIMARY KEY,
--   `rate_percentage` DECIMAL(5,2) NOT NULL UNIQUE,
--   `description` VARCHAR(100) DEFAULT NULL,
--   `is_active` BOOLEAN DEFAULT TRUE
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- INSERT INTO `gst_rates` (`rate_percentage`, `description`) VALUES
-- (0.00, '0% GST'),
-- (0.10, '0.1% GST'),
-- (0.25, '0.25% GST'),
-- (3.00, '3% GST'),
-- (5.00, '5% GST'),
-- (12.00, '12% GST'),
-- (18.00, '18% GST'),
-- (28.00, '28% GST');

-- CREATE TABLE IF NOT EXISTS `hsn_sac_codes` (
--   `id` INT AUTO_INCREMENT PRIMARY KEY,
--   `code` VARCHAR(20) NOT NULL UNIQUE,
--   `description` TEXT NOT NULL,
--   `type` ENUM('HSN', 'SAC') NOT NULL,
--   `default_gst_rate_id` INT DEFAULT NULL,
--   FOREIGN KEY (`default_gst_rate_id`) REFERENCES `gst_rates`(`id`) ON DELETE SET NULL
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------