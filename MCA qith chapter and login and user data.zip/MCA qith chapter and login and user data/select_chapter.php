<?php
session_start();
if (!isset($_SESSION['student_info'])) {
    header('Location: student_info.php');
    exit;
}
include 'db.php';

// Get selected category from GET or default to NEET
$category = $_GET['category'] ?? 'NEET';

// Fetch chapters for the selected category only
$stmt = $db->prepare("SELECT * FROM chapters WHERE category=?");
$stmt->bind_param("s", $category);
$stmt->execute();
$chapters = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Select Chapter</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #181a1b; color: #fff; }
        .rules-box { background: #23272b; color: #fff; border-left: 5px solid #0dcaf0; }
    </style>
</head>
<body>
<div class="container py-5">
    <h2 class="mb-4 text-center">Select Category & Chapter</h2>
    
    <!-- Marking Scheme & Rules -->
    <div class="alert rules-box mb-4">
        <h5 class="mb-2">Quiz Rules & Marking Scheme</h5>
        <ul class="mb-0">
            <li>Each correct answer: <span class="text-success fw-bold">+4 marks</span></li>
            <li>Each incorrect answer: <span class="text-danger fw-bold">-1 mark</span></li>
            <li>No marks for unattempted questions</li>
            <li>Once submitted, answers cannot be changed</li>
            <li>Do not refresh the page during the quiz</li>
        </ul>
    </div>
    
    <form class="mx-auto" style="max-width:400px;" method="get" action="">
        <div class="mb-3">
            <label class="form-label">Category</label>
            <select class="form-select form-select-lg" name="category" onchange="this.form.submit()" required>
                <option value="NEET" <?= $category=='NEET'?'selected':'' ?>>NEET</option>
                <option value="IIT-JEE Mains" <?= $category=='IIT-JEE Mains'?'selected':'' ?>>IIT-JEE Mains</option>
<option value="IIT-JEE Advanced" <?= $category=='IIT-JEE Advanced'?'selected':'' ?>>IIT-JEE Advanced</option>

                <option value="BITSAT" <?= $category=='BITSAT'?'selected':'' ?>>BITSAT</option>
            </select>
        </div>
    </form>
    <form class="mx-auto" style="max-width:400px;" method="get" action="quiz.php">
        <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
        <div class="mb-3">
            <label class="form-label">Chapter</label>
            <select class="form-select form-select-lg" name="chapter_id" required>
                <option value="">-- Select a Chapter --</option>
                <?php while($row = $chapters->fetch_assoc()): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-info w-100 btn-lg select-btn">Start Quiz</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
</html>
