<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $error = '';

    if ($name === '' || $phone === '' || $email === '') {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    }

    if (!$error) {
        $_SESSION['student_info'] = [
            'name' => $name,
            'phone' => $phone,
            'email' => $email
        ];
        header('Location: select_chapter.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Student Registration | Quiz Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap and Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    body {
        background-color: #121212;
        color: #ffffff;
        font-family: 'Segoe UI', sans-serif;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        padding: 20px;
    }

    .form-box {
        background-color: #1e1e1e;
        padding: 40px;
        border-radius: 15px;
        max-width: 500px;
        width: 100%;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.6);
        animation: fadeIn 0.5s ease-in;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .form-box h2 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: 600;
    }

    .form-control,
    .form-control:focus {
        background-color: #2c2c2c;
        color: #fff;
        border: 1px solid #444;
        border-radius: 8px;
    }

    .input-group-text {
        background-color: #2c2c2c;
        border: 1px solid #444;
        color: #bbb;
    }

    .btn-primary {
        background-color: #0d6efd;
        border: none;
        font-weight: 600;
        border-radius: 8px;
    }

    .btn-primary:hover {
        background-color: #0b5ed7;
    }

    .error-message {
        background-color: #dc3545;
        color: #fff;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
        text-align: center;
    }

    ::placeholder {
        color: #ffffff !important;
        opacity: 1;
        /* Make sure it's fully visible */
    }
    </style>
</head>

<body>
    <div class="form-box">
        <h2>Student Registration</h2>
        <p class="text-center text-secondary mb-4">Enter your details to begin the quiz</p>

        <?php if (!empty($error)): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                    <input type="text" name="name" class="form-control" placeholder="Your full name" required
                        value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Phone Number</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-telephone-fill"></i></span>
                    <input type="text" name="phone" class="form-control" placeholder="Enter phone number" required
                        value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                    <input type="email" name="email" class="form-control" placeholder="Enter email address" required
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 mt-3">Proceed to Quiz <i
                    class="bi bi-arrow-right-circle-fill ms-2"></i></button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>