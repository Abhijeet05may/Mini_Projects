<?php
include 'admin_auth.php';
include 'navbar.php';
include 'db.php';

// Get category filter from GET or default to NEET
$category = $_GET['category'] ?? 'NEET';
// Get search term for chapter name
$search = trim($_GET['search'] ?? '');

// Fetch all chapters for mapping id to name
$chapterMap = [];
$res = $db->query("SELECT id, name FROM chapters");
while ($row = $res->fetch_assoc()) {
    $chapterMap[$row['id']] = $row['name'];
}

// Build query
$params = [];
$types = '';
$sql = "SELECT * FROM questions WHERE category=?";
$params[] = $category;
$types .= 's';

if ($search !== '') {
    // Find chapter IDs matching the search
    $stmt = $db->prepare("SELECT id FROM chapters WHERE name LIKE ?");
    $like = "%$search%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
    $chapter_ids = [];
    while ($row = $result->fetch_assoc()) {
        $chapter_ids[] = $row['id'];
    }
    if ($chapter_ids) {
        $in = implode(',', array_fill(0, count($chapter_ids), '?'));
        $sql .= " AND chapter_id IN ($in)";
        foreach ($chapter_ids as $id) {
            $params[] = $id;
            $types .= 'i';
        }
    } else {
        // No chapters match search, so no results
        $questions = [];
    }
}

if (!isset($questions)) {
    $stmt = $db->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $questions = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Manage Questions</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <style>
    body {
        background: #181a1b;
        color: #fff;
    }

    .table-dark th,
    .table-dark td {
        color: #fff;
    }

    .category-badge {
        font-size: 0.95em;
    }
    </style>
</head>

<body>
    <div class="container py-5">
        <div class="bg-dark p-4 rounded shadow-lg">
            <h2 class="mb-4 text-center">Manage Questions</h2>
            <form class="row g-3 mb-4" method="get" autocomplete="off">
                <div class="col-md-4">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select" required>
                        <option value="NEET" <?= $category=='NEET'?'selected':'' ?>>NEET</option>
                        <option value="IIT-JEE Mains" <?= $category=='IIT-JEE Mains'?'selected':'' ?>>IIT-JEE Mains
                        </option>
                        <option value="IIT-JEE Advanced" <?= $category=='IIT-JEE Advanced'?'selected':'' ?>>IIT-JEE
                            Advanced</option>
                        <option value="BITSAT" <?= $category=='BITSAT'?'selected':'' ?>>BITSAT</option>
                    </select>

                </div>
                <div class="col-md-5">
                    <label class="form-label">Search by Chapter Name</label>
                    <input type="text" class="form-control" name="search" placeholder="Enter chapter name"
                        value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-info w-100">Search</button>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Category</th>
                            <th>Chapter</th>
                            <th>Question</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                $sn = 1;
                if ($questions instanceof mysqli_result) {
                    while ($q = $questions->fetch_assoc()):
                        $chapterName = $chapterMap[$q['chapter_id']] ?? 'N/A';
                ?>
                        <tr>
                            <td><?= $sn++ ?></td>
                            <td>
                                <span
                                    class="badge bg-primary category-badge"><?= htmlspecialchars($q['category']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($chapterName) ?></td>
                            <td><?= htmlspecialchars(mb_strimwidth($q['question'], 0, 80, '...')) ?></td>
                            <td>
                                <a href="admin_edit.php?id=<?= $q['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="admin_delete.php?id=<?= $q['id'] ?>" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Delete this question?')">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile;
                }
                if ($sn == 1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-warning">No questions found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous">
    </script>
    
</body>

</html>