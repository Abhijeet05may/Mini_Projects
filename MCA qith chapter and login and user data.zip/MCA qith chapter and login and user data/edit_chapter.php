<?php
include 'admin_auth.php';
include 'navbar.php';
include 'db.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: manage_chapter.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $category = $_POST['category'];
    $stmt = $db->prepare("UPDATE chapters SET name=?, category=? WHERE id=?");
    $stmt->bind_param("ssi", $name, $category, $id);
    $stmt->execute();
    header("Location: manage_chapter.php?msg=updated");
    exit;
}

$stmt = $db->prepare("SELECT * FROM chapters WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$ch = $stmt->get_result()->fetch_assoc();
if (!$ch) { header('Location: manage_chapter.php'); exit; }

$categories = ['NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Chapter</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { background: #181a1b; color: #fff; }</style>
</head>
<body>
<div class="container py-5">
    <div class="bg-dark p-4 rounded shadow-lg" style="max-width: 500px; margin: auto;">
        <h2 class="mb-4 text-center">Edit Chapter</h2>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Chapter Name</label>
                <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($ch['name']) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Category</label>
                <select name="category" class="form-select" required>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat ?>" <?= $ch['category']==$cat?'selected':'' ?>><?= $cat ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success w-100">Update Chapter</button>
        </form>
    </div>
</div>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
</html>
