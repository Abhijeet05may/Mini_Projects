<style>
    .footer { background: #23272b; color: #bbb; text-align: center; padding: 1rem 0; margin-top: auto; }
</style>

<footer class="footer mt-5">
    Designed by Junk Solutions
</footer>