/mcq/
  ├── admin_dashboard.php
  ├── admin_add.php
  ├── admin_manage.php
  ├── admin_scores.php
  ├── admin_delete_score.php
  ├── manage_chapter.php
  ├── add_chapter.php
  ├── edit_chapter.php
  ├── admin_nav.php
  ├── student_info.php   // first step to start the quiz to fill the user form
  ├── select_chapter.php  // select the topic and category
  ├── quiz.php // quizz
  ├── db.php
  ├── admin_auth.php
  ├── uploads/           (for question/solution images)
  └── ...other files
