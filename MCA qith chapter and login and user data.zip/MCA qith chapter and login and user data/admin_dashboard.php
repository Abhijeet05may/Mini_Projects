<?php
session_start();
include 'navbar.php';
include 'db.php';

// Get total number of chapters
$total_chapters = $db->query("SELECT COUNT(*) FROM chapters")->fetch_row()[0];

// Get total number of questions
$total_questions = $db->query("SELECT COUNT(*) FROM questions")->fetch_row()[0];

// Get total number of student entries (quiz attempts)
$total_student_entries = $db->query("SELECT COUNT(*) FROM student_scores")->fetch_row()[0];

// Updated categories
$categories = ['NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT'];
$category_counts = [];
$stmt = $db->prepare("SELECT COUNT(*) FROM questions WHERE category=?");
foreach ($categories as $cat) {
    $stmt->bind_param("s", $cat);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $category_counts[$cat] = $count;
    $stmt->reset();
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #181a1b; color: #fff; min-height: 100vh; display: flex; flex-direction: column; }
        .dashboard-container { flex: 1; }
        .card { background: #23272b; color: #fff; }
        .footer { background: #23272b; color: #bbb; text-align: center; padding: 1rem 0; margin-top: auto; }
        .cat-badge { font-size: 1.1em; }
        .mb-4 { margin-bottom: 4.5rem !important;}
    </style>
</head>
<body>

<div class="container dashboard-container py-5">
    <h2 class="mb-4 text-center">
  Welcome, <span class="text-danger">Admin</span>
</h2>

    <div class="row g-4 justify-content-center mb-4">
        <div class="col-md-3">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h4 class="card-title">Total Chapters</h4>
                    <p class="display-6 fw-bold"><?= $total_chapters ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h4 class="card-title">Total Questions</h4>
                    <p class="display-6 fw-bold"><?= $total_questions ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h4 class="card-title">Student Entries</h4>
                    <p class="display-6 fw-bold"><?= $total_student_entries ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-4 justify-content-center">
        <?php foreach ($categories as $cat): ?>
        <div class="col-md-3">
            <div class="card text-center shadow border-info">
                <div class="card-body">
                    <h5 class="card-title">
                        <span class="badge bg-info cat-badge"><?= htmlspecialchars($cat) ?></span>
                    </h5>
                    <div class="mt-2 mb-2">
                        <span class="display-6 fw-bold"><?= $category_counts[$cat] ?></span>
                        <div class="text-muted">Questions</div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<footer class="footer mt-5">
    designed by junk solutions
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
