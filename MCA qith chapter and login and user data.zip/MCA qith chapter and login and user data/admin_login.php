<?php
session_start();
include 'db.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $msg = "All fields are required.";
    } else {
        $stmt = $db->prepare("SELECT id, password FROM admins WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows == 1) {
            $stmt->bind_result($admin_id, $hash);
            $stmt->fetch();
            if (password_verify($password, $hash)) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $admin_id;
                $_SESSION['admin_username'] = $username;
                header("Location: admin_dashboard.php");
                exit;
            } else {
                $msg = "Invalid username or password.";
            }
        } else {
            $msg = "Invalid username or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(-45deg, #0f0c29, #302b63, #24243e);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            color: #fff;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .login-card {
            background-color: rgba(0, 0, 0, 0.75);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease;
        }

        .login-card:hover {
            transform: scale(1.02);
        }

        .form-control {
            background: #1e1e2f;
            color: #fff;
            border: 1px solid #555;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            background: #222;
            border-color: #6f42c1;
            box-shadow: 0 0 10px rgba(111, 66, 193, 0.5);
        }

        .btn-primary {
            background-color: #6f42c1;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #8e5ce2;
            transform: translateY(-2px);
            box-shadow: 0 8px 15px rgba(143, 92, 226, 0.3);
        }

        .container-center {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .logo-text {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .logo-text span {
            color: violet;
        }

        .alert {
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="container container-center">
    <div class="text-center logo-text"><span>Physics</span> Navigator</div>
    <br>
    <div class="login-card col-md-4">
        <h3 class="text-center mb-4">Admin Login</h3>

        <?php if ($msg): ?>
            <div class="alert alert-danger text-center"><?= $msg ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter username" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
<?php include 'footer.php'; ?>
</body>
</html>
