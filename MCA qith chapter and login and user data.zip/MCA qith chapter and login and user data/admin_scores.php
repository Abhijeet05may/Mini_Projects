<?php
include 'admin_auth.php';
include 'navbar.php';
include 'db.php';

// --- Handle Search ---
$search = trim($_GET['search'] ?? '');

// --- Handle Sorting ---
$sortable_columns = [
    'name', 'phone', 'email', 'category', 'chapter_name', 'score', 'correct', 'wrong', 'attempted', 'submitted_at'
];
$sort = $_GET['sort'] ?? 'submitted_at';
$order = $_GET['order'] ?? 'desc';
if (!in_array($sort, $sortable_columns)) $sort = 'submitted_at';
$order = strtolower($order) === 'asc' ? 'asc' : 'desc';

// --- Build Query ---
$where = '';
$params = [];
$types = '';
if ($search !== '') {
    $where = "WHERE (s.name LIKE ? OR s.phone LIKE ? OR s.email LIKE ?)";
    $like = "%$search%";
    $params = [$like, $like, $like];
    $types = 'sss';
}

$sql = "SELECT s.*, c.name AS chapter_name FROM student_scores s LEFT JOIN chapters c ON s.chapter_id = c.id ";
if ($where) $sql .= $where . " ";
$sql .= "ORDER BY $sort $order";

// --- Prepare and Execute ---
$stmt = $db->prepare($sql);
if ($where) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Scores</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #181a1b; color: #fff; }
        .table-dark th, .table-dark td { color: #fff; }
        .sortable:hover { text-decoration: underline; cursor: pointer; color: #0dcaf0; }
        .sort-arrow { font-size: 0.9em; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="bg-dark p-4 rounded shadow-lg">
        <h2 class="mb-4 text-center">Student Quiz Results</h2>
        <!-- Search Bar -->
        <form class="row g-3 mb-4" method="get" autocomplete="off">
            <div class="col-md-10">
                <input type="text" class="form-control" name="search" placeholder="Search by name, phone, or email..." value="<?= htmlspecialchars($search) ?>">
                <!-- Keep sort/order in search -->
                <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">
                <input type="hidden" name="order" value="<?= htmlspecialchars($order) ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-info w-100">Search</button>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-dark table-hover align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <?php
                        // Helper for sortable columns
                        function sortable($label, $col, $sort, $order, $search) {
                            $arrow = '';
                            if ($sort == $col) $arrow = $order == 'asc' ? '▲' : '▼';
                            $next_order = ($sort == $col && $order == 'asc') ? 'desc' : 'asc';
                            $params = [
                                'sort' => $col,
                                'order' => $next_order
                            ];
                            if ($search !== '') $params['search'] = $search;
                            $url = '?' . http_build_query($params);
                            return "<a href=\"$url\" class=\"sortable\">$label <span class=\"sort-arrow\">$arrow</span></a>";
                        }
                        ?>
                        <th><?= sortable('Name', 'name', $sort, $order, $search) ?></th>
                        <th><?= sortable('Phone', 'phone', $sort, $order, $search) ?></th>
                        <th><?= sortable('Email', 'email', $sort, $order, $search) ?></th>
                        <th><?= sortable('Category', 'category', $sort, $order, $search) ?></th>
                        <th><?= sortable('Chapter', 'chapter_name', $sort, $order, $search) ?></th>
                        <th><?= sortable('Score', 'score', $sort, $order, $search) ?></th>
                        <th><?= sortable('Correct', 'correct', $sort, $order, $search) ?></th>
                        <th><?= sortable('Wrong', 'wrong', $sort, $order, $search) ?></th>
                        <th><?= sortable('Attempted', 'attempted', $sort, $order, $search) ?></th>
                        <th><?= sortable('Date & Time', 'submitted_at', $sort, $order, $search) ?></th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $sn=1; while($row = $res->fetch_assoc()): ?>
                    <tr>
                        <td><?= $sn++ ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['phone']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['category']) ?></td>
                        <td><?= htmlspecialchars($row['chapter_name'] ?? 'N/A') ?></td>
                        <td><?= $row['score'] ?></td>
                        <td><?= $row['correct'] ?></td>
                        <td><?= $row['wrong'] ?></td>
                        <td><?= $row['attempted'] ?></td>
                        <td><?= $row['submitted_at'] ?></td>
                        <td>
                            <a href="admin_delete_score.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this score?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                <?php if ($sn == 1): ?>
                    <tr><td colspan="12" class="text-center text-warning">No records found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
<?php include 'footer.php'; ?>
</html>
