<?php
include 'admin_auth.php'; // Protect admin access
include 'navbar.php';
include 'db.php';

// Get selected category from GET or default to NEET
$category = $_GET['category'] ?? 'NEET';

// Fetch chapters for the selected category only
$stmt = $db->prepare("SELECT id, name FROM chapters WHERE category=?");
$stmt->bind_param("s", $category);
$stmt->execute();
$chapters = $stmt->get_result();

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $chapter_id = intval($_POST['chapter_id'] ?? 0);
    $question = trim($_POST['question'] ?? '');
    $option1 = trim($_POST['option1'] ?? '');
    $option2 = trim($_POST['option2'] ?? '');
    $option3 = trim($_POST['option3'] ?? '');
    $option4 = trim($_POST['option4'] ?? '');
    $correct_option = trim($_POST['correct_option'] ?? '');
    $solution = trim($_POST['solution'] ?? '');
    $category = $_POST['category'] ?? $category; // Use POST value if set

    // Handle image uploads (optional)
    $question_img = '';
    $solution_img = '';
    if (isset($_FILES['question_img']) && $_FILES['question_img']['size'] > 0) {
        $target = 'uploads/q_' . time() . '_' . basename($_FILES['question_img']['name']);
        if (move_uploaded_file($_FILES['question_img']['tmp_name'], $target)) {
            $question_img = $target;
        }
    }
    if (isset($_FILES['solution_img']) && $_FILES['solution_img']['size'] > 0) {
        $target = 'uploads/s_' . time() . '_' . basename($_FILES['solution_img']['name']);
        if (move_uploaded_file($_FILES['solution_img']['tmp_name'], $target)) {
            $solution_img = $target;
        }
    }

    // Insert question
    $stmt = $db->prepare("INSERT INTO questions (chapter_id, question, option1, option2, option3, option4, correct_option, solution, question_img, solution_img, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssssss", $chapter_id, $question, $option1, $option2, $option3, $option4, $correct_option, $solution, $question_img, $solution_img, $category);
    $stmt->execute();

    $msg = "Question added successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Question</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #181a1b; color: #fff; }
        .form-container { max-width: 700px; margin: 0 auto; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="form-container bg-dark p-4 rounded shadow-lg">
        <h2 class="mb-4 text-center">Add New Question</h2>
        <?php if ($msg): ?>
            <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>
        <!-- CATEGORY SELECTION (reloads page on change) -->
        <form method="get" class="mb-4" style="max-width:400px;margin:auto;">
            <div class="mb-3">
                <label class="form-label">Category</label>
                <select name="category" class="form-select" onchange="this.form.submit()" required>
                    <option value="NEET" <?= $category=='NEET'?'selected':'' ?>>NEET</option>
                    <option value="IIT-JEE Mains" <?= $category=='IIT-JEE Mains'?'selected':'' ?>>IIT-JEE Mains</option>
                    <option value="IIT-JEE Advanced" <?= $category=='IIT-JEE Advanced'?'selected':'' ?>>IIT-JEE Advanced</option>
                    <option value="BITSAT" <?= $category=='BITSAT'?'selected':'' ?>>BITSAT</option>
                </select>
            </div>
        </form>
        <!-- MAIN ADD QUESTION FORM -->
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
            <div class="mb-3">
                <label class="form-label">Chapter</label>
                <select name="chapter_id" class="form-select" required>
                    <option value="">Select Chapter</option>
                    <?php while ($ch = $chapters->fetch_assoc()): ?>
                        <option value="<?= $ch['id'] ?>"><?= htmlspecialchars($ch['name']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Question</label>
                <textarea name="question" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Question Image (optional)</label>
                <input type="file" name="question_img" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">Option 1</label>
                <input type="text" name="option1" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Option 2</label>
                <input type="text" name="option2" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Option 3</label>
                <input type="text" name="option3" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Option 4</label>
                <input type="text" name="option4" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Correct Option (1-4)</label>
                <input type="number" name="correct_option" class="form-control" min="1" max="4" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Solution</label>
                <textarea name="solution" class="form-control"></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Solution Image (optional)</label>
                <input type="file" name="solution_img" class="form-control">
            </div>
            <button type="submit" class="btn btn-success w-100">Add Question</button>
        </form>
        <div class="text-center mt-4">
            <a href="admin_manage.php" class="btn btn-warning btn-lg">Back to Manage Questions</a>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
<?php include 'footer.php' ; ?>
</body>
</html>
