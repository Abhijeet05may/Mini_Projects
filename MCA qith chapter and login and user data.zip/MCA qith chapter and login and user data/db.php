<?php
$host = "localhost";
$user = "root";
$pass = ""; // your MySQL password
$dbname = "mcq_app";
$db = new mysqli($host, $user, $pass, $dbname);
if ($db->connect_error) die("DB Connection failed: " . $db->connect_error);
?>
