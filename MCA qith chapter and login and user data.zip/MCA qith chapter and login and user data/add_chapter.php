<?php
include 'admin_auth.php'; // Protect admin access
include 'navbar.php';
include 'db.php';

$name = '';
$category = 'NEET';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category = $_POST['category'] ?? 'NEET';

    if ($name === '') {
        $msg = "Chapter name is required.";
    } else {
        $stmt = $db->prepare("INSERT INTO chapters (name, category) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $category);
        $stmt->execute();
        $msg = "Chapter added successfully!";
        $name = '';
        $category = 'NEET';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Add Chapter</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background: #181a1b;
        color: #fff;
    }

    .form-container {
        max-width: 400px;
        margin: 0 auto;
    }
    </style>
</head>

<body>
    <div class="container py-5">
        <div class="form-container bg-dark p-4 rounded shadow-lg">
            <h2 class="mb-4 text-center">Add Chapter</h2>
            <?php if ($msg): ?>
            <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>
            <form method="POST" autocomplete="off">
                <div class="mb-3">
                    <label class="form-label">Chapter Name</label>
                    <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($name) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select" required>
                        <option value="NEET" <?= $category=='NEET'?'selected':'' ?>>NEET</option>
                        <option value="IIT-JEE Mains" <?= $category=='IIT-JEE Mains'?'selected':'' ?>>IIT-JEE Mains
                        </option>
                        <option value="IIT-JEE Advanced" <?= $category=='IIT-JEE Advanced'?'selected':'' ?>>IIT-JEE
                            Advanced</option>
                        <option value="BITSAT" <?= $category=='BITSAT'?'selected':'' ?>>BITSAT</option>
                    </select>

                </div>
                <button type="submit" class="btn btn-success w-100">Add Chapter</button>
            </form>
            <div class="text-center mt-4">
                <a href="admin_dashboard.php" class="btn btn-warning btn-lg">Back to Dashboard</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
<?php include 'footer.php' ; ?>
</html>