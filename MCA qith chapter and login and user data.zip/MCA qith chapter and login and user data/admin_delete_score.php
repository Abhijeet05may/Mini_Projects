<?php
include 'admin_auth.php';
include 'db.php';

$id = intval($_GET['id'] ?? 0);
if ($id) {
    $db->query("DELETE FROM student_scores WHERE id=$id");
}
header("Location: admin_scores.php");
exit;
