<?php
include 'admin_auth.php';
include 'navbar.php';
include 'db.php';

// Handle delete action
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $db->query("DELETE FROM chapters WHERE id=$id");
    header("Location: manage_chapter.php?msg=deleted");
    exit;
}

// Handle search
$search = trim($_GET['search'] ?? '');

// Fetch chapters with search filter
if ($search !== '') {
    $stmt = $db->prepare("SELECT * FROM chapters WHERE name LIKE ? OR category LIKE ? ORDER BY category, name");
    $like = "%$search%";
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = $db->query("SELECT * FROM chapters ORDER BY category, name");
}
$chapters = [];
while ($row = $res->fetch_assoc()) $chapters[] = $row;

// Handle success messages
$msg = '';
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $msg = "Chapter deleted successfully!";
}
if (isset($_GET['msg']) && $_GET['msg'] == 'updated') {
    $msg = "Chapter updated successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Chapters</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #181a1b; color: #fff; }
        .table-dark th, .table-dark td { color: #fff; }
        .category-badge { font-size: 0.95em; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="bg-dark p-4 rounded shadow-lg">
        <h2 class="mb-4 text-center">Manage Chapters</h2>
        <!-- Search Bar -->
        <form class="row g-3 mb-4" method="get" autocomplete="off">
            <div class="col-md-8">
                <input type="text" class="form-control" name="search" placeholder="Search by chapter name or category..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-info w-100">Search</button>
            </div>
        </form>
        <?php if ($msg): ?>
            <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-dark table-hover align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Chapter Name</th>
                        <th>Category</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php $sn=1; foreach ($chapters as $ch): ?>
                    <tr>
                        <td><?= $sn++ ?></td>
                        <td><?= htmlspecialchars($ch['name']) ?></td>
                        <td>
                            <span class="badge bg-info category-badge"><?= htmlspecialchars($ch['category']) ?></span>
                        </td>
                        <td>
                            <a href="edit_chapter.php?id=<?= $ch['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="manage_chapter.php?delete=<?= $ch['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this chapter? This will not delete questions in this chapter.')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if ($sn == 1): ?>
                    <tr><td colspan="4" class="text-center text-warning">No chapters found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
<?php include 'footer.php'; ?>
</body>
</html>
