<style>
        .navbar-custom { background: #23272b; }
        .nav-link, .navbar-brand { color: #fff !important; }
        .nav-link:hover { color: #0dcaf0 !important; }
        .text-violet {color: violet;}
        .text-green {color:rgb(24, 154, 143) ;}
        .text-yellow {color: yellow;}
        .nav-link.text-danger:hover {color: darkred;}
</style>
    
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="admin_dashboard.php"><span class="text-violet">Physics</span> Navigator</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="adminNavbar">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="admin_scores.php"><span class="text-yellow"> Score </span></a></li>
        <li class="nav-item"><a class="nav-link" href="admin_manage.php"><span class="text-yellow"> Manage Questions</span></a></li>
        <li class="nav-item"><a class="nav-link" href="admin_add.php"><span class="text-yellow">Add Question</span></a></li>
        <li class="nav-item"><a class="nav-link" href="add_chapter.php"><span class="text-yellow">Add Chapter</span></a></li>
        <li class="nav-item"><a class="nav-link" href=manage_chapter.php><span class="text-yellow">Manage Chapter</span></a></li>
        <li class="nav-item"><a class="nav-link" href="select_chapter.php"><span class="text-Green">Quiz</span></a></li>
        <li class="nav-item">
  <a class="nav-link text-danger" href="logout.php">Logout</a>
</li>
      </ul>
    </div>
  </div>
</nav>
