<?php
session_start();
include 'db.php';

if (!isset($_SESSION['student_info'])) {
    header("Location: student_info.php");
    exit;
}

if (!isset($_GET['category']) || !isset($_GET['chapter_id'])) {
    die('Category and chapter required.');
}

$category = $_GET['category'];
$chapter_id = intval($_GET['chapter_id']);

// Fetch chapter name
$stmt = $db->prepare("SELECT name FROM chapters WHERE id=?");
$stmt->bind_param("i", $chapter_id);
$stmt->execute();
$stmt->bind_result($chapter_name);
$stmt->fetch();
$stmt->close();

if (!$chapter_name) {
    die('Invalid chapter.');
}

// Fetch questions for this chapter and category
$stmt = $db->prepare("SELECT * FROM questions WHERE chapter_id=? AND category=?");
$stmt->bind_param("is", $chapter_id, $category);
$stmt->execute();
$res = $stmt->get_result();
$questions = [];
while ($row = $res->fetch_assoc()) $questions[] = $row;
shuffle($questions);

// Handle AJAX score save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_save_score'])) {
    $score = intval($_POST['score']);
    $attempted = intval($_POST['attempted']);
    $correct = intval($_POST['correct']);
    $wrong = intval($_POST['wrong']);
    $student = $_SESSION['student_info'];
    $total_questions = count($questions);

    $stmt = $db->prepare("INSERT INTO student_scores (name, phone, email, category, chapter_id, score, total_questions, attempted, correct, wrong, submitted_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssiiiiii", $student['name'], $student['phone'], $student['email'], $category, $chapter_id, $score, $total_questions, $attempted, $correct, $wrong);
    $stmt->execute();

    // Optionally clear student info for next quiz
    unset($_SESSION['student_info']);
    echo 'OK';
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Quiz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #181a1b; color: #fff; }
        .quiz-box { max-width: 700px; margin: 0 auto; }
        .option-label { cursor: pointer; }
        .question-img-large {
            display: block;
            width: 100%;
            max-width: 100%;
            height: auto;
            margin: 0.5rem 0 1rem 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px #0004;
            object-fit: contain;
            background: #222;
        }
        .solution-box { background: #222; color: #bff; border-left: 4px solid #0dcaf0; padding: 0.7rem 1rem; margin: 0.7rem 0 1.3rem 0; border-radius: 6px;}
    </style>
</head>
<body>
<div class="container py-5">
    <div class="quiz-box bg-dark p-4 rounded shadow-lg">
        <div class="mb-3 text-center">
            <span class="badge bg-primary fs-6"><?= htmlspecialchars($category) ?></span>
            <span class="badge bg-success fs-6"><?= htmlspecialchars($chapter_name) ?></span>
        </div>
        <h2 class="mb-4 text-center">Quiz</h2>
        <div id="quiz-content"></div>
    </div>
</div>
<script>
const questions = <?= json_encode($questions) ?>;
let current = 0;
let answers = Array(questions.length).fill(null);
let quizEnded = false;

function attemptedCount() {
    return answers.filter(a => a !== null).length;
}

function renderQuestion() {
    if (quizEnded) return;
    const q = questions[current];
    let html = '';
    html += `<div class="d-flex justify-content-between mb-2">
        <button class="btn btn-secondary" onclick="prevQ()" ${current==0?'disabled':''}>Previous</button>
        <span>Question ${current+1} of ${questions.length}</span>
        <button class="btn btn-primary" onclick="nextQ()" ${current==questions.length-1?'disabled':''}>Next</button>
    </div>`;
    html += `<div class="d-flex justify-content-between align-items-center mb-2">
                <span>Attempted: <span id="attemptedCount">${attemptedCount()}</span> / ${questions.length}</span>
            </div>`;
    html += `<div class="mb-3"><strong>Q${current+1}:</strong> ${q.question}</div>`;
    if (q.question_img) {
        html += `<img src="${q.question_img}" class="question-img-large">`;
    }
    for (let i = 1; i <= 4; i++) {
        html += `<div class="form-check mb-2">
            <input class="form-check-input" type="radio" name="option" id="opt${i}" value="${i}" ${answers[current]==i?'checked':''} onchange="saveAnswer()">
            <label class="form-check-label option-label" for="opt${i}">${q['option'+i]}</label>
        </div>`;
    }
    html += `<div class="text-center mt-4">
        <button class="btn btn-success btn-lg" onclick="finalSubmit()">Final Submit</button>
    </div>`;
    document.getElementById('quiz-content').innerHTML = html;
    document.getElementById('attemptedCount').textContent = attemptedCount();
}

function prevQ() {
    saveAnswer();
    if (current > 0) current--;
    renderQuestion();
}
function nextQ() {
    saveAnswer();
    if (current < questions.length-1) {
        current++;
        renderQuestion();
    }
}
function saveAnswer() {
    const selected = document.querySelector('input[name="option"]:checked');
    answers[current] = selected ? parseInt(selected.value) : null;
    if (document.getElementById('attemptedCount'))
        document.getElementById('attemptedCount').textContent = attemptedCount();
}

function finalSubmit() {
    saveAnswer();
    quizEnded = true;
    let score = 0, correctCount = 0, wrongCount = 0, attempted = 0;
    let resultArr = [];
    for (let i = 0; i < questions.length; i++) {
        const q = questions[i];
        const userAns = answers[i];
        if (userAns === null) continue;
        attempted++;
        let correct = (userAns === parseInt(q.correct_option));
        if (correct) {
            score += 4;
            correctCount++;
        } else {
            score -= 1;
            wrongCount++;
        }
        resultArr.push({q, userAns, correct, idx: i});
    }
    // Save score via AJAX
    fetch('', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            ajax_save_score: 1,
            score: score,
            attempted: attempted,
            correct: correctCount,
            wrong: wrongCount
        })
    })
    .then(res => res.text())
    .then(text => {
        let msg = (text.trim() === 'OK')
            ? '<div class="alert alert-success">Your score has been saved!</div>'
            : '<div class="alert alert-danger">There was a problem saving your score.</div>';
        showResult(resultArr, score, correctCount, wrongCount, attempted, msg);
    });
}

function showResult(resultArr, score, correctCount, wrongCount, attempted, msg) {
    let solHTML = msg;
    solHTML += `<div class="alert alert-info mb-4 text-center">
        <strong>Attempted: ${attempted}</strong> &nbsp; 
        <span class="text-success">Correct: ${correctCount}</span> &nbsp; 
        <span class="text-danger">Wrong: ${wrongCount}</span><br>
        <span class="fw-bold">Your Score: ${score}</span>
    </div>`;
    solHTML += `<h4 class="mb-3">Attempted Questions & Solutions</h4>`;
    if (resultArr.length === 0) {
        solHTML += `<div class="alert alert-warning">You did not attempt any questions.</div>`;
    }
    for (let item of resultArr) {
        const {q, userAns, correct, idx} = item;
        solHTML += `<div class="mb-2"><strong>Q${idx+1}:</strong> ${q.question}`;
        if (q.question_img) {
            solHTML += `<img src="${q.question_img}" class="question-img-large">`;
        }
        solHTML += `</div>`;
        if (correct) {
            solHTML += `<div class="mb-2">Your Answer: <strong class="text-success">${userAns} (Correct)</strong></div>`;
        } else {
            solHTML += `<div class="mb-2">Your Answer: <strong class="text-danger">${userAns} (Wrong)</strong></div>`;
            solHTML += `<div class="mb-2">Correct Answer: <strong class="text-success">${q.correct_option}</strong></div>`;
        }
        solHTML += `<div class="solution-box"><strong>Solution:</strong><br>${q.solution ? q.solution : '<em>No solution provided.</em>'}`;
        if (q.solution_img) {
            solHTML += `<br><img src="${q.solution_img}" class="question-img-large">`;
        }
        solHTML += `</div>`;
    }
    solHTML += `<div class="text-center"><button class="btn btn-primary btn-lg mt-3" onclick="location.reload()">Retake Quiz</button></div>`;
    document.getElementById('quiz-content').innerHTML = solHTML;
}

// Render first question
renderQuestion();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
</html>
