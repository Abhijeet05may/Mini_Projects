-- MCQ System Database Structure
-- Database: `mcq_app`
--

-- --------------------------------------------------------

-- 1. Chapters Table
CREATE TABLE IF NOT EXISTS chapters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category ENUM('NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT') NOT NULL
);

-- 2. Questions Table
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chapter_id INT NOT NULL,
    question TEXT NOT NULL,
    option1 VARCHAR(255) NOT NULL,
    option2 VARCHAR(255) NOT NULL,
    option3 VARCHAR(255) NOT NULL,
    option4 VARCHAR(255) NOT NULL,
    correct_option TINYINT NOT NULL,
    solution TEXT,
    question_img VARCHAR(255),
    solution_img VARCHAR(255),
    category ENUM('NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT') NOT NULL,
    FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
);

-- 3. Student Scores Table
CREATE TABLE IF NOT EXISTS student_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    category ENUM('NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT') NOT NULL,
    chapter_id INT NOT NULL,
    score INT NOT NULL,
    total_questions INT NOT NULL,
    attempted INT NOT NULL,
    correct INT NOT NULL,
    wrong INT NOT NULL,
    submitted_at DATETIME NOT NULL,
    FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
);

-- If you are updating an existing database, run these to update old categories:
UPDATE chapters SET category = 'IIT-JEE Mains' WHERE category = 'IIT-JEE';
UPDATE questions SET category = 'IIT-JEE Mains' WHERE category = 'IIT-JEE';
UPDATE student_scores SET category = 'IIT-JEE Mains' WHERE category = 'IIT-JEE';

-- If you are updating an existing database, run these to update ENUMs:
ALTER TABLE chapters MODIFY category ENUM('NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT') NOT NULL;
ALTER TABLE questions MODIFY category ENUM('NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT') NOT NULL;
ALTER TABLE student_scores MODIFY category ENUM('NEET', 'IIT-JEE Mains', 'IIT-JEE Advanced', 'BITSAT') NOT NULL;
