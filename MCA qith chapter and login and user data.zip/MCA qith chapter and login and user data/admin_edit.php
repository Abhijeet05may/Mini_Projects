<?php
include 'admin_auth.php'; // Protect admin access
include 'navbar.php';
include 'db.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) die("Invalid ID");

// Fetch question
$stmt = $db->prepare("SELECT * FROM questions WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$q = $stmt->get_result()->fetch_assoc();
if (!$q) die("Question not found!");

// Fetch chapters for dropdown
$chapters = $db->query("SELECT id, name FROM chapters");

// Handle form submission
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $chapter_id = intval($_POST['chapter_id'] ?? $q['chapter_id']);
    $question = trim($_POST['question'] ?? '');
    $option1 = trim($_POST['option1'] ?? '');
    $option2 = trim($_POST['option2'] ?? '');
    $option3 = trim($_POST['option3'] ?? '');
    $option4 = trim($_POST['option4'] ?? '');
    $correct_option = trim($_POST['correct_option'] ?? '');
    $solution = trim($_POST['solution'] ?? '');
    $category = $_POST['category'] ?? 'NEET';

    // Handle image uploads (optional)
    $question_img = $q['question_img'];
    $solution_img = $q['solution_img'];
    if (isset($_FILES['question_img']) && $_FILES['question_img']['size'] > 0) {
        $target = 'uploads/q_' . time() . '_' . basename($_FILES['question_img']['name']);
        if (move_uploaded_file($_FILES['question_img']['tmp_name'], $target)) {
            $question_img = $target;
        }
    }
    if (isset($_FILES['solution_img']) && $_FILES['solution_img']['size'] > 0) {
        $target = 'uploads/s_' . time() . '_' . basename($_FILES['solution_img']['name']);
        if (move_uploaded_file($_FILES['solution_img']['tmp_name'], $target)) {
            $solution_img = $target;
        }
    }

    // Update question
    $stmt = $db->prepare("UPDATE questions SET chapter_id=?, question=?, option1=?, option2=?, option3=?, option4=?, correct_option=?, solution=?, question_img=?, solution_img=?, category=? WHERE id=?");
    $stmt->bind_param("issssssssssi", $chapter_id, $question, $option1, $option2, $option3, $option4, $correct_option, $solution, $question_img, $solution_img, $category, $id);
    $stmt->execute();

    $msg = "Question updated successfully!";
    // Refresh question data
    $stmt = $db->prepare("SELECT * FROM questions WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $q = $stmt->get_result()->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Edit Question</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background: #181a1b;
        color: #fff;
    }

    .form-container {
        max-width: 700px;
        margin: 0 auto;
    }

    .img-thumb {
        max-width: 120px;
        max-height: 80px;
        border-radius: 5px;
        box-shadow: 0 2px 8px #0004;
    }
    </style>
</head>

<body>
    <div class="container py-5">
        <div class="form-container bg-dark p-4 rounded shadow-lg">
            <h2 class="mb-4 text-center">Edit Question</h2>
            <?php if ($msg): ?>
            <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">Chapter</label>
                    <select name="chapter_id" class="form-select" required>
                        <?php foreach ($chapters as $ch): ?>
                        <option value="<?= $ch['id'] ?>" <?= $ch['id']==$q['chapter_id']?'selected':'' ?>>
                            <?= htmlspecialchars($ch['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select" required>
                        <option value="NEET" <?= $category=='NEET'?'selected':'' ?>>NEET</option>
                        <option value="IIT-JEE Mains" <?= $category=='IIT-JEE Mains'?'selected':'' ?>>IIT-JEE Mains
                        </option>
                        <option value="IIT-JEE Advanced" <?= $category=='IIT-JEE Advanced'?'selected':'' ?>>IIT-JEE
                            Advanced</option>
                        <option value="BITSAT" <?= $category=='BITSAT'?'selected':'' ?>>BITSAT</option>
                    </select>

                </div>
                <div class="mb-3">
                    <label class="form-label">Question</label>
                    <textarea name="question" class="form-control"
                        required><?= htmlspecialchars($q['question']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Question Image (optional)</label><br>
                    <?php if ($q['question_img']): ?>
                    <img src="<?= htmlspecialchars($q['question_img']) ?>" class="img-thumb mb-2"><br>
                    <?php endif; ?>
                    <input type="file" name="question_img" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Option 1</label>
                    <input type="text" name="option1" class="form-control" required
                        value="<?= htmlspecialchars($q['option1']) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Option 2</label>
                    <input type="text" name="option2" class="form-control" required
                        value="<?= htmlspecialchars($q['option2']) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Option 3</label>
                    <input type="text" name="option3" class="form-control" required
                        value="<?= htmlspecialchars($q['option3']) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Option 4</label>
                    <input type="text" name="option4" class="form-control" required
                        value="<?= htmlspecialchars($q['option4']) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Correct Option (1-4)</label>
                    <input type="number" name="correct_option" class="form-control" min="1" max="4" required
                        value="<?= htmlspecialchars($q['correct_option']) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Solution</label>
                    <textarea name="solution" class="form-control"><?= htmlspecialchars($q['solution']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Solution Image (optional)</label><br>
                    <?php if ($q['solution_img']): ?>
                    <img src="<?= htmlspecialchars($q['solution_img']) ?>" class="img-thumb mb-2"><br>
                    <?php endif; ?>
                    <input type="file" name="solution_img" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary w-100">Update Question</button>
            </form>
            <div class="text-center mt-4">
                <a href="admin_manage.php" class="btn btn-warning btn-lg">Back to Manage Questions</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
</body>
<?php include 'footer.php' ; ?>
</html>