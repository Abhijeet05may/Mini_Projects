<?php
include 'db_connection.php';

$task_date = $_POST['task_date'];
$task_description = $_POST['task_description'];

$sql = "INSERT INTO tasks (task_date, task_description) VALUES ('$task_date', '$task_description')";

if ($conn->query($sql) === TRUE) {
  echo "New task added successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>