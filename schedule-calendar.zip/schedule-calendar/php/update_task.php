<?php
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $task_id = $_POST['task_id'];
    $is_completed = $_POST['is_completed'];

    $stmt = $conn->prepare("UPDATE tasks SET is_completed = ? WHERE id = ?");
    $stmt->bind_param("ii", $is_completed, $task_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "updated"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Update failed"]);
    }
    $stmt->close();
}
?>
