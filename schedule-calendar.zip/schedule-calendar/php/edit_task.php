<?php
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $task_date = $_POST['task_date'];
    $task_description = $_POST['task_description'];
    $priority = $_POST['priority'];

    $stmt = $conn->prepare("INSERT INTO tasks (task_date, task_description, priority) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $task_date, $task_description, $priority);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Task insertion failed"]);
    }
    $stmt->close();
}
?>
