<?php
require 'db_connection.php';

if (isset($_GET['month'])) {
    $month = $_GET['month']; // format YYYY-MM
    $stmt = $conn->prepare("SELECT * FROM tasks WHERE task_date LIKE CONCAT(?, '%')");
    $stmt->bind_param("s", $month);
    $stmt->execute();
    $result = $stmt->get_result();

    $tasks = [];
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }

    echo json_encode($tasks);
    $stmt->close();
}
?>
