-- SQL setup for the Clarity Calendar application
-- Run this code in your MySQL database (e.g., via phpMyAdmin)
-- to create the necessary table.

-- It's recommended to create a new database for this project:
-- CREATE DATABASE calendar_db;
-- USE calendar_db;

-- This table will store all the tasks.
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_date` date NOT NULL,
  `task_description` varchar(255) NOT NULL,
  `is_completed` tinyint(1) NOT NULL DEFAULT 0,
  `priority` varchar(10) NOT NULL DEFAULT 'medium',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

