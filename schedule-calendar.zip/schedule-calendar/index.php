<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clarity Calendar</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <style>
        /* --- Base Styles --- */
        body {
            font-family: 'Inter', sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* --- Scrollbar --- */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #9ca3af; }

        /* --- Main Layout --- */
        .main-container {
            display: grid;
            grid-template-columns: 6fr 4fr; /* 60% Calendar, 40% Agenda */
            gap: 2rem;
            height: 95vh;
            padding: 1.5rem;
        }

        .calendar-panel, .agenda-panel {
            background: white;
            border-radius: 1.5rem;
            padding: 1.5rem;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
            display: flex;
            flex-direction: column;
        }

        /* --- Calendar Panel --- */
        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .calendar-header h2 { font-size: 1.5rem; font-weight: 700; }
        .nav-btn {
            background-color: #f3f4f6;
            color: #4b5563;
            border-radius: 50%;
            width: 2.5rem;
            height: 2.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease-in-out;
        }
        .nav-btn:hover { background-color: #e5e7eb; transform: scale(1.1); }
        .calendar-grid { flex-grow: 1; display: grid; grid-template-rows: auto 1fr; }
        .weekdays { display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; color: #6b7280; font-weight: 600; padding-bottom: 0.75rem;}
        .days-grid { display: grid; grid-template-columns: repeat(7, 1fr); grid-auto-rows: minmax(100px, auto); gap: 0.5rem; }

        .day {
            padding: 0.75rem;
            border-radius: 0.75rem;
            transition: all 0.2s ease-in-out;
            border: 2px solid transparent;
            position: relative;
        }
        .day:not(.other-month):hover { background-color: #f9fafb; }
        .day.other-month { color: #d1d5db; }
        .day .day-number { font-weight: 600; font-size: 1rem; }
        .day.today { background-color: #ecfdf5; color: #065f46; font-weight: 700; }
        .day.selected { border-color: #3b82f6; background-color: #eff6ff; }

        .add-task-hover {
            position: absolute;
            top: 5px;
            right: 5px;
            background: #3b82f6;
            color: white;
            border-radius: 50%;
            width: 22px;
            height: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            opacity: 0;
            transform: scale(0.8);
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .day:hover .add-task-hover { opacity: 1; transform: scale(1); }
        .task-dot {
            position: absolute;
            bottom: 8px;
            left: 50%;
            transform: translateX(-50%);
            width: 6px;
            height: 6px;
            background-color: #ef4444;
            border-radius: 50%;
        }

        /* --- Agenda Panel --- */
        .agenda-header h3 { font-size: 1.5rem; font-weight: 700; }
        .agenda-header .date-str { color: #6b7280; font-weight: 500; }

        .task-list { flex-grow: 1; overflow-y: auto; margin-top: 1.5rem; padding-right: 0.5rem; }
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            text-align: center;
            color: #9ca3af;
        }
        .empty-state svg { width: 80px; height: 80px; margin-bottom: 1rem; }
        .empty-state p { font-weight: 500; }

        .task-item {
            display: flex;
            align-items: start;
            gap: 1rem;
            background-color: #f9fafb;
            padding: 1rem;
            border-radius: 0.75rem;
            margin-bottom: 1rem;
        }
        .task-item input[type="checkbox"] { margin-top: 5px; width: 18px; height: 18px; cursor: pointer; accent-color: #3b82f6;}
        .task-item .task-content { flex-grow: 1; }
        .task-item .task-description { font-weight: 500; }
        .task-item.completed .task-description { text-decoration: line-through; color: #9ca3af; }
        .priority-tag {
            padding: 2px 8px;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-top: 0.5rem;
            display: inline-block;
        }
        .priority-low { background-color: #dbeafe; color: #1e40af; }
        .priority-medium { background-color: #fef3c7; color: #92400e; }
        .priority-high { background-color: #fee2e2; color: #991b1b; }
        .task-actions button { background: none; border: none; color: #9ca3af; cursor: pointer; transition: color 0.2s ease;}
        .task-actions button:hover { color: #374151; }
        
        /* --- Add Task Form --- */
        .add-task-form { margin-top: auto; padding-top: 1rem; border-top: 1px solid #e5e7eb; }
        .add-task-form input { width: 100%; border: 1px solid #d1d5db; border-radius: 0.5rem; padding: 0.75rem; margin-bottom: 0.75rem; }
        .add-task-form .priority-selector { display: flex; gap: 0.5rem; margin-bottom: 0.75rem; }
        .add-task-form .priority-btn {
            flex-grow: 1;
            padding: 0.5rem;
            border-radius: 0.5rem;
            border: 1px solid #d1d5db;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .add-task-form .priority-btn.selected {
            font-weight: 600;
            transform: scale(1.05);
            box-shadow: 0 0 0 2px #3b82f6;
        }
        .add-task-form .submit-btn {
            width: 100%;
            background-color: #2563eb;
            color: white;
            font-weight: 600;
            padding: 0.75rem;
            border-radius: 0.5rem;
            transition: background-color 0.2s ease;
        }
        .add-task-form .submit-btn:hover { background-color: #1d4ed8; }
        body.dark {
    background-color: #111827;
    color: #e5e7eb;
}

body.dark .calendar-panel,
body.dark .agenda-panel {
    background-color: #1f2937;
    box-shadow: none;
}

body.dark .day:not(.other-month):hover {
    background-color: #374151;
}

body.dark .day.selected {
    background-color: #3b82f6;
    border-color: #60a5fa;
    color: #fff;
}

body.dark .day.today {
    background-color: #065f46;
    color: #d1fae5;
}

body.dark .add-task-hover {
    background-color: #2563eb;
}

body.dark .task-item {
    background-color: #374151;
    color: #f3f4f6;
}

body.dark .task-item.completed .task-description {
    color: #9ca3af;
}

body.dark .priority-low {
    background-color: #1e3a8a;
    color: #bfdbfe;
}
body.dark .priority-medium {
    background-color: #78350f;
    color: #fde68a;
}
body.dark .priority-high {
    background-color: #7f1d1d;
    color: #fecaca;
}

body.dark .empty-state {
    color: #9ca3af;
}

body.dark .add-task-form input {
    background-color: #1f2937;
    border-color: #374151;
    color: #f3f4f6;
}

body.dark .priority-btn {
    background-color: #1f2937;
    color: #f3f4f6;
}

body.dark .priority-btn.selected {
    box-shadow: 0 0 0 2px #3b82f6;
}

body.dark .submit-btn {
    background-color: #3b82f6;
}

    </style>
</head>
<body class="bg-gray-100">
    
<button id="toggle-dark" class="px-4 py-2 bg-black text-white font-semibold rounded-lg hover:bg-gray-800 transition-all ml-2">Dark Mode</button>

    <div class="main-container">
        <!-- Calendar Panel -->
        <div class="calendar-panel">
            <div class="calendar-header">
                <div class="flex items-center space-x-4">
                    <button id="prev-month-btn" class="nav-btn"><i class="fas fa-chevron-left"></i></button>
                    <h2 id="month-year"></h2>
                    <button id="next-month-btn" class="nav-btn"><i class="fas fa-chevron-right"></i></button>
                </div>
                 <button id="today-btn" class="px-4 py-2 bg-blue-100 text-blue-700 font-semibold rounded-lg hover:bg-blue-200 transition-all">Today</button>
            </div>
            <div class="calendar-grid">
                <div class="weekdays"></div>
                <div class="days-grid"></div>
            </div>
        </div>

        <!-- Agenda Panel -->
        <div class="agenda-panel">
            <div class="agenda-header">
                <h3 id="agenda-title"></h3>
                <p id="agenda-date-str" class="date-str"></p>
            </div>
            <div id="task-list" class="task-list">
                <!-- Tasks will be rendered here by JS -->
            </div>
            <div class="add-task-form">
                 <input type="text" id="new-task-input" placeholder="What do you need to do?">
                 <div class="priority-selector">
                     <button class="priority-btn" data-priority="low">Low</button>
                     <button class="priority-btn selected" data-priority="medium">Medium</button>
                     <button class="priority-btn" data-priority="high">High</button>
                 </div>
                 <button id="submit-task-btn" class="submit-btn">Add Task</button>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', () => {

    // --- DOM Elements ---
    const monthYearEl = document.getElementById('month-year');
    const prevMonthBtn = document.getElementById('prev-month-btn');
    const nextMonthBtn = document.getElementById('next-month-btn');
    const todayBtn = document.getElementById('today-btn');
    const weekdaysEl = document.querySelector('.weekdays');
    const daysGridEl = document.querySelector('.days-grid');
    
    const agendaTitleEl = document.getElementById('agenda-title');
    const agendaDateStrEl = document.getElementById('agenda-date-str');
    const taskListEl = document.getElementById('task-list');
    
    const newTaskInput = document.getElementById('new-task-input');
    const prioritySelector = document.querySelector('.priority-selector');
    const submitTaskBtn = document.getElementById('submit-task-btn');

    // --- State ---
    let currentDate = new Date();
    let selectedDate = new Date();
    let tasksForMonth = {};

    // --- Formatters & Helpers ---
    const formatDateKey = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

    const formatAgendaTitle = (date) => {
        const today = new Date();
        const tomorrow = new Date();
        tomorrow.setDate(today.getDate() + 1);

        if (formatDateKey(date) === formatDateKey(today)) return 'Today';
        if (formatDateKey(date) === formatDateKey(tomorrow)) return 'Tomorrow';
        return date.toLocaleDateString('en-US', { weekday: 'long' });
    };

    // --- API ---
    async function fetchTasksForMonth(year, month) {
        try {
            const response = await fetch(`php/get_tasks.php?month=${year}-${String(month + 1).padStart(2, '0')}`);
            const tasks = await response.json();
            tasksForMonth = {}; // Reset
            tasks.forEach(task => {
                if (!tasksForMonth[task.task_date]) {
                    tasksForMonth[task.task_date] = [];
                }
                tasksForMonth[task.task_date].push(task);
            });
        } catch (error) {
            console.error('Failed to fetch tasks:', error);
        }
    }

    async function apiCall(url, body) {
        try {
            const response = await fetch(url, { method: 'POST', body });
            if (!response.ok) throw new Error('API call failed');
            return true;
        } catch (error) {
            console.error(error);
            return false;
        }
    }
    
    // --- Render Functions ---
    async function renderCalendar() {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        
        await fetchTasksForMonth(year, month);
        
        monthYearEl.textContent = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        
        weekdaysEl.innerHTML = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => `<div>${day}</div>`).join('');
        daysGridEl.innerHTML = '';

        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const todayKey = formatDateKey(new Date());
        const selectedKey = formatDateKey(selectedDate);

        // Days from previous month
        const prevMonthDays = new Date(year, month, 0).getDate();
        for (let i = firstDayOfMonth - 1; i >= 0; i--) {
            daysGridEl.innerHTML += `<div class="day other-month"><div class="day-number">${prevMonthDays - i}</div></div>`;
        }
        
        // Days of current month
        for (let i = 1; i <= daysInMonth; i++) {
            const dayDate = new Date(year, month, i);
            const dayKey = formatDateKey(dayDate);
            
            const dayEl = document.createElement('div');
            dayEl.className = 'day';
            dayEl.dataset.date = dayKey;
            
            if (dayKey === todayKey) dayEl.classList.add('today');
            if (dayKey === selectedKey) dayEl.classList.add('selected');
            
            dayEl.innerHTML = `
                <div class="day-number">${i}</div>
                <div class="add-task-hover"><i class="fas fa-plus"></i></div>
                ${tasksForMonth[dayKey] ? '<div class="task-dot"></div>' : ''}
            `;
            daysGridEl.appendChild(dayEl);
        }
        renderAgenda();
    }
    
    function renderAgenda() {
        agendaTitleEl.textContent = formatAgendaTitle(selectedDate);
        agendaDateStrEl.textContent = selectedDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
        
        const dateKey = formatDateKey(selectedDate);
        const tasks = tasksForMonth[dateKey] || [];
        
        taskListEl.innerHTML = '';
        if (tasks.length === 0) {
            taskListEl.innerHTML = `
                <div class="empty-state">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0h18M-4.5 12h22.5" />
                    </svg>
                    <p>No tasks for this day.</p>
                    <p class="text-sm text-gray-400">Enjoy your free time!</p>
                </div>`;
            return;
        }

        tasks.sort((a,b) => a.is_completed - b.is_completed).forEach(task => {
            const taskEl = document.createElement('div');
            taskEl.className = 'task-item';
            if (task.is_completed == 1) taskEl.classList.add('completed');
            taskEl.dataset.taskId = task.id;

            taskEl.innerHTML = `
                <input type="checkbox" ${task.is_completed == 1 ? 'checked' : ''}>
                <div class="task-content">
                    <p class="task-description">${task.task_description}</p>
                    <span class="priority-tag priority-${task.priority}">${task.priority}</span>
                </div>
                <div class="task-actions">
                    <button class="delete-btn"><i class="fas fa-trash"></i></button>
                </div>
            `;
            taskListEl.appendChild(taskEl);
        });
    }

    // --- Event Handlers ---
    daysGridEl.addEventListener('click', (e) => {
        const dayEl = e.target.closest('.day');
        if (dayEl && !dayEl.classList.contains('other-month')) {
            document.querySelector('.day.selected')?.classList.remove('selected');
            dayEl.classList.add('selected');
           const [year, month, day] = dayEl.dataset.date.split('-').map(Number);
            selectedDate = new Date(year, month - 1, day);

            renderAgenda();
        }
    });

    taskListEl.addEventListener('click', async (e) => {
        const taskItem = e.target.closest('.task-item');
        if (!taskItem) return;

        const taskId = taskItem.dataset.taskId;
        const formData = new FormData();
        formData.append('task_id', taskId);

        // Checkbox click
        if (e.target.type === 'checkbox') {
            formData.append('is_completed', e.target.checked ? 1 : 0);
            if (await apiCall('php/update_task.php', formData)) {
                 await renderCalendar();
            }
        }

        // Delete button click
        if (e.target.closest('.delete-btn')) {
             if (await apiCall('php/delete_task.php', formData)) {
                 await renderCalendar();
            }
        }
    });

    submitTaskBtn.addEventListener('click', async () => {
        const description = newTaskInput.value.trim();
        if (!description) return;
        
        const selectedPriority = prioritySelector.querySelector('.selected').dataset.priority;
        const formData = new FormData();
        formData.append('task_date', formatDateKey(selectedDate));
        formData.append('task_description', description);
        formData.append('priority', selectedPriority);

        if (await apiCall('php/add_task.php', formData)) {
            newTaskInput.value = '';
            await renderCalendar();
        }
    });
    
    prioritySelector.addEventListener('click', (e) => {
        if (e.target.classList.contains('priority-btn')) {
            prioritySelector.querySelector('.selected').classList.remove('selected');
            e.target.classList.add('selected');
        }
    });

    prevMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    });

    nextMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    });

    todayBtn.addEventListener('click', () => {
        currentDate = new Date();
        selectedDate = new Date();
        renderCalendar();
    });
    
    // --- Initial Load ---
    renderCalendar();
});
// Theme Toggle
const toggleDarkBtn = document.getElementById('toggle-dark');

// Apply saved theme
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark');
    toggleDarkBtn.textContent = 'Light Mode';
}

toggleDarkBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark');
    const isDark = document.body.classList.contains('dark');
    toggleDarkBtn.textContent = isDark ? 'Light Mode' : 'Dark Mode';
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
});

</script>
</body>
</html>
