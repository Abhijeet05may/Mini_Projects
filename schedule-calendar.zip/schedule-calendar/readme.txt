project/
│
├── db_connection.php
├── schedule-calendar.html
├── php/
│   ├── add_task.php
│   ├── get_tasks.php
│   ├── update_task.php
│   └── delete_task.php
└── db.sql
