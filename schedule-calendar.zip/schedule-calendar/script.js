document.addEventListener('DOMContentLoaded', function () {
    // --- DOM Elements ---
    const loadingOverlay = document.getElementById('loading-overlay');
    const monthYearEl = document.getElementById('month-year');
    const calendarDaysEl = document.getElementById('calendar-days');
    const calendarWeekdaysEl = document.getElementById('calendar-weekdays');
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');
    const todayBtn = document.getElementById('today-btn');
    const darkModeToggle = document.getElementById('dark-mode-toggle');

    const taskModal = document.getElementById('task-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const modalDateEl = document.getElementById('modal-date');
    const taskListEl = document.getElementById('task-list');
    const taskInput = document.getElementById('task-input');
    const addTaskBtn = document.getElementById('add-task-btn');

    // --- State ---
    let currentDate = new Date();
    let selectedDateStr = '';
    let tasksForMonth = {};

    // --- Utility Functions ---
    const showLoader = (show) => {
        loadingOverlay.style.display = show ? 'flex' : 'none';
    };

    const formatDate = (date) => {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    };

    // --- API Calls ---
    const fetchTasksForMonth = async (year, month) => {
        showLoader(true);
        try {
            const response = await fetch(`php/get_tasks.php?month=${year}-${String(month + 1).padStart(2, '0')}`);
            const tasks = await response.json();
            tasksForMonth = {};
            tasks.forEach(task => {
                if (!tasksForMonth[task.task_date]) {
                    tasksForMonth[task.task_date] = [];
                }
                tasksForMonth[task.task_date].push(task);
            });
        } catch (error) {
            console.error('Failed to fetch tasks:', error);
        } finally {
            showLoader(false);
        }
    };

    const apiCall = async (url, body) => {
        try {
            const response = await fetch(url, { method: 'POST', body });
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.text();
        } catch (error) {
            console.error('API call failed:', error);
            return null;
        }
    };

    // --- Calendar Rendering ---
    const renderCalendar = async () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        await fetchTasksForMonth(year, month);

        monthYearEl.textContent = new Date(year, month).toLocaleString('default', { month: 'long', year: 'numeric' });
        calendarDaysEl.innerHTML = '';
        calendarWeekdaysEl.innerHTML = '';

        const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        daysOfWeek.forEach(day => {
            calendarWeekdaysEl.innerHTML += `<div>${day}</div>`;
        });

        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const todayStr = formatDate(new Date());

        for (let i = 0; i < firstDayOfMonth; i++) {
            calendarDaysEl.innerHTML += `<div class="calendar-day other-month"></div>`;
        }

        for (let i = 1; i <= daysInMonth; i++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            const dayEl = document.createElement('div');
            dayEl.className = 'calendar-day';
            dayEl.dataset.date = dateStr;
            if (dateStr === todayStr) {
                dayEl.classList.add('today');
            }

            dayEl.innerHTML = `<div class="day-number">${i}</div>`;
            if (tasksForMonth[dateStr]) {
                dayEl.innerHTML += `<div class="task-indicator"></div>`;
            }
            dayEl.addEventListener('click', () => openModal(dateStr));
            calendarDaysEl.appendChild(dayEl);
        }
    };

    // --- Modal and Task Handling ---
    const openModal = (dateStr) => {
        selectedDateStr = dateStr;
        const dateObj = new Date(dateStr + 'T00:00:00');
        modalDateEl.textContent = dateObj.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
        renderTasksInModal();
        taskModal.style.display = 'flex';
    };

    const closeModal = () => {
        taskModal.style.display = 'none';
        taskInput.value = '';
    };

    const renderTasksInModal = () => {
        taskListEl.innerHTML = '';
        const tasks = tasksForMonth[selectedDateStr] || [];
        if (tasks.length === 0) {
            taskListEl.innerHTML = '<p class="text-gray-500">No tasks for this day.</p>';
            return;
        }

        tasks.forEach(task => {
            const taskEl = document.createElement('div');
            taskEl.className = 'task-item';
            if (task.is_completed === "1") taskEl.classList.add('completed');
            taskEl.dataset.taskId = task.id;

            taskEl.innerHTML = `
                <input type="checkbox" ${task.is_completed === "1" ? 'checked' : ''}>
                <span class="task-desc">${task.task_description}</span>
                <div class="task-actions">
                    <button class="edit-btn"><i class="fas fa-edit"></i></button>
                    <button class="delete-btn"><i class="fas fa-trash"></i></button>
                </div>
            `;
            taskListEl.appendChild(taskEl);
        });
    };

    const addTask = async () => {
        const description = taskInput.value.trim();
        if (!description) return;

        const formData = new FormData();
        formData.append('task_date', selectedDateStr);
        formData.append('task_description', description);

        showLoader(true);
        await apiCall('php/add_task.php', formData);
        await renderCalendar(); // Re-render calendar for indicator dot
        openModal(selectedDateStr); // Re-open and render modal
        showLoader(false);
        taskInput.value = '';
    };

    const updateTaskStatus = async (taskId, isCompleted) => {
        const formData = new FormData();
        formData.append('task_id', taskId);
        formData.append('is_completed', isCompleted ? 1 : 0);
        await apiCall('php/update_task.php', formData);
    };

    const deleteTask = async (taskId) => {
        if (!confirm('Are you sure you want to delete this task?')) return;
        const formData = new FormData();
        formData.append('task_id', taskId);
        showLoader(true);
        await apiCall('php/delete_task.php', formData);
        await renderCalendar();
        openModal(selectedDateStr);
        showLoader(false);
    };

    const editTask = (taskEl) => {
        const taskDescEl = taskEl.querySelector('.task-desc');
        const currentDesc = taskDescEl.textContent;
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentDesc;
        input.className = 'edit-input';
        
        taskDescEl.replaceWith(input);
        input.focus();

        const save = async () => {
            const newDesc = input.value.trim();
            if (newDesc && newDesc !== currentDesc) {
                const taskId = taskEl.dataset.taskId;
                const formData = new FormData();
                formData.append('task_id', taskId);
                formData.append('task_description', newDesc);
                showLoader(true);
                await apiCall('php/edit_task.php', formData);
                tasksForMonth[selectedDateStr].find(t => t.id === taskId).task_description = newDesc; // Update local state
                showLoader(false);
            }
             renderTasksInModal();
        };

        input.addEventListener('blur', save);
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') input.blur();
            if (e.key === 'Escape') {
                input.replaceWith(taskDescEl); // Cancel edit
            }
        });
    };

    // --- Event Listeners ---
    prevMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    });

    nextMonthBtn.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    });

    todayBtn.addEventListener('click', () => {
        currentDate = new Date();
        renderCalendar();
    });

    darkModeToggle.addEventListener('click', () => {
        document.documentElement.classList.toggle('dark');
        darkModeToggle.querySelector('i').classList.toggle('fa-moon');
        darkModeToggle.querySelector('i').classList.toggle('fa-sun');
    });

    closeModalBtn.addEventListener('click', closeModal);
    window.addEventListener('click', (e) => {
        if (e.target === taskModal) closeModal();
    });

    addTaskBtn.addEventListener('click', addTask);
    taskInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') addTask();
    });

    taskListEl.addEventListener('click', (e) => {
        const taskEl = e.target.closest('.task-item');
        if (!taskEl) return;
        const taskId = taskEl.dataset.taskId;

        if (e.target.type === 'checkbox') {
            updateTaskStatus(taskId, e.target.checked);
            taskEl.classList.toggle('completed', e.target.checked);
        } else if (e.target.closest('.edit-btn')) {
            editTask(taskEl);
        } else if (e.target.closest('.delete-btn')) {
            deleteTask(taskId);
        }
    });

    // --- Initial Load ---
    renderCalendar();
});